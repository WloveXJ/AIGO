'use strict';

const { app, BrowserWindow, protocol, Menu, shell } = require('electron');
const path = require('path');
const url = require('url');
const fs = require('fs');

// ---------------------------------------------------------------------------
// Paths: everything lives next to the executable, so the folder is portable.
// ---------------------------------------------------------------------------
const APP_DIR = path.dirname(process.execPath);
const DATA_DIR = path.join(APP_DIR, 'data');

// The board is plain 2D canvas, so software rendering is plenty. Keeping the
// GPU inside the browser process avoids driver crashes in VMs / RDP sessions.
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('disable-gpu-compositing');
app.commandLine.appendSwitch('in-process-gpu');
app.disableHardwareAcceleration();

try {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  app.setPath('userData', DATA_DIR);
} catch (err) {
  // read-only folder: fall back to the default userData location
}

const ROOT = __dirname;
const APP_HOST = 'goai';
const START_PAGE = 'app://' + APP_HOST + '/index.html';

// A custom scheme must be declared before "ready" to be treated as a secure,
// standard origin. Web Workers and IndexedDB both require that.
protocol.registerSchemesAsPrivileged([
  {
    scheme: 'app',
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      corsEnabled: true,
      stream: true,
      codeCache: true
    }
  }
]);

function logError(message) {
  try {
    fs.appendFileSync(path.join(DATA_DIR, 'error.log'),
      new Date().toISOString() + '  ' + message + '\r\n');
  } catch (err) { /* ignore */ }
}

let mainWindow = null;

function registerAppProtocol() {
  protocol.registerFileProtocol('app', (request, callback) => {
    try {
      const parsed = new url.URL(request.url);
      let rel = decodeURIComponent(parsed.pathname || '/');
      if (rel === '/' || rel === '') rel = '/index.html';

      const resolved = path.normalize(path.join(ROOT, rel));

      if (!resolved.toLowerCase().startsWith(ROOT.toLowerCase()) ||
          !fs.existsSync(resolved) ||
          !fs.statSync(resolved).isFile()) {
        callback({ error: -6 }); // FILE_NOT_FOUND
        return;
      }
      callback({ path: resolved });
    } catch (err) {
      logError('protocol error: ' + err.message);
      callback({ error: -2 }); // FAILED
    }
  });
}

function createWindow() {
  const iconPath = path.join(ROOT, 'icon.ico');

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 1030,
    minWidth: 1080,
    minHeight: 780,
    show: false,
    backgroundColor: '#f5f1e8',
    title: '围棋 · 本地 AI',
    autoHideMenuBar: true,
    icon: fs.existsSync(iconPath) ? iconPath : undefined,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      // Sandboxing the renderer blocks custom-scheme loads in this Chromium
      // build; the page has no Node access either way.
      sandbox: false,
      spellcheck: false,
      // 训练只在窗口可见时进行：最小化后由 Chromium 节流定时器，
      // 页面里也会主动给 worker 发 pause。
      backgroundThrottling: true
    }
  });

  Menu.setApplicationMenu(null);
  mainWindow.setMenuBarVisibility(false);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.webContents.setWindowOpenHandler(({ url: target }) => {
    if (target.startsWith('http://') || target.startsWith('https://')) {
      shell.openExternal(target);
    }
    return { action: 'deny' };
  });

  mainWindow.webContents.on('will-navigate', (event, target) => {
    if (!target.startsWith('app://' + APP_HOST + '/')) event.preventDefault();
  });

  mainWindow.webContents.on('did-fail-load', (event, code, desc, validatedURL) => {
    logError('did-fail-load code=' + code + ' desc=' + desc + ' url=' + validatedURL);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  mainWindow.loadURL(START_PAGE).catch((err) => {
    logError('loadURL failed: ' + err.message);
  });
}

const gotLock = app.requestSingleInstanceLock();

if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.setAppUserModelId('com.local.goai');

  app.whenReady().then(() => {
    registerAppProtocol();
    createWindow();

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  }).catch((err) => {
    logError('whenReady failed: ' + err.message);
  });

  app.on('window-all-closed', () => {
    app.quit();
  });
}
