/*
 * memory-store.js —— AI 的"记忆"
 *  - patterns：3x3 棋型 → 落子胜率统计（自我对弈累积）
 *  - book：局面哈希 → 各落点统计（开局库）
 *  - 持久化：IndexedDB，失败回退 localStorage
 */
(function (global) {
  'use strict';

  var EMPTY = 0, BLACK = 1, WHITE = 2;
  var DB_NAME = 'go-ai-memory-v1';
  var DB_VERSION = 2;
  var STORE = 'state';
  var KEY = 'brain';
  var STAGE_STORE = 'stages';     // 段位阶段存档（摘要）
  var SNAP_STORE = 'snapshots';   // 阶段存档的完整记忆快照
  var STAGE_FULL_KEEP = 6;        // 只保留最近 6 份完整快照，其余只留摘要
  var BOOK_LIMIT = 4000;

  // 角上/边上的格子按"墙"处理，共 4 种状态 → 4^8 = 65536
  function patternKey(game, i, color) {
    var size = game.size, b = game.board;
    var x = i % size, y = (i / size) | 0;
    var key = 0;
    for (var dy = -1; dy <= 1; dy++) {
      for (var dx = -1; dx <= 1; dx++) {
        if (dx === 0 && dy === 0) continue;
        var nx = x + dx, ny = y + dy;
        var st;
        if (nx < 0 || ny < 0 || nx >= size || ny >= size) st = 3;
        else {
          var v = b[ny * size + nx];
          if (v === EMPTY) st = 0;
          else if (v === color) st = 1;      // 相对落子方归一化，黑白共用同一张表
          else st = 2;
        }
        key = key * 4 + st;
      }
    }
    return key;
  }

  function GoMemory() {
    this.patterns = {};   // key -> [visits, wins]
    this.book = {};       // hash -> { move: [visits, wins] }
    this.meta = { games: 0, updated: 0, version: 1, humanGames: 0, lastResult: null };
    this._delta = null;
    this._db = null;
    this._ready = false;
    this._flushTimer = null;
    this._resetDelta();
  }

  GoMemory.prototype._resetDelta = function () {
    this._delta = { patterns: {}, book: {}, games: 0, humanGames: 0, lastResult: null };
  };

  GoMemory.prototype.init = function () {
    var self = this;
    if (this._ready) return Promise.resolve(this);

    // IndexedDB 在个别环境（隐私模式 / 无头浏览器）可能长时间无响应，
    // 超过 1.6s 就降级，避免整个界面卡住。
    return new Promise(function (resolve) {
      var settled = false;
      var timer = setTimeout(function () {
        if (settled) return;
        settled = true;
        self._loadLocal();
        self._ready = true;
        resolve(self);
      }, 1600);

      self._openDB().then(function (db) {
        self._db = db;
        return self._read();
      }).then(function (state) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (state) {
          self.patterns = state.patterns || {};
          self.book = state.book || {};
          self.meta = Object.assign(self.meta, state.meta || {});
        }
        self._ready = true;
        resolve(self);
      }).catch(function () {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        self._loadLocal();
        self._ready = true;
        resolve(self);
      });
    });
  };

  // 兜底：localStorage / 纯内存
  GoMemory.prototype._loadLocal = function () {
    try {
      if (!global.localStorage) return;
      var raw = global.localStorage.getItem(DB_NAME);
      if (!raw) return;
      var s = JSON.parse(raw);
      this.patterns = s.patterns || {};
      this.book = s.book || {};
      this.meta = Object.assign(this.meta, s.meta || {});
    } catch (e) { /* ignore */ }
  };

  GoMemory.prototype._openDB = function () {
    return new Promise(function (resolve, reject) {
      if (!global.indexedDB) return reject(new Error('no idb'));
      var req = global.indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
        if (!db.objectStoreNames.contains(STAGE_STORE)) {
          db.createObjectStore(STAGE_STORE, { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains(SNAP_STORE)) {
          db.createObjectStore(SNAP_STORE);
        }
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error); };
    });
  };

  GoMemory.prototype._read = function () {
    var db = this._db;
    if (!db) return Promise.resolve(null);
    return new Promise(function (resolve) {
      var tx = db.transaction(STORE, 'readonly');
      var req = tx.objectStore(STORE).get(KEY);
      req.onsuccess = function () { resolve(req.result || null); };
      req.onerror = function () { resolve(null); };
    });
  };

  GoMemory.prototype._write = function (state) {
    var db = this._db;
    if (!db) {
      try {
        if (global.localStorage) global.localStorage.setItem(DB_NAME, JSON.stringify(state));
      } catch (e) { /* ignore */ }
      return Promise.resolve();
    }
    return new Promise(function (resolve) {
      var tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(state, KEY);
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { resolve(); };
    });
  };

  // 记录一局：moves = [{i, color, patKey, h, no}]
  GoMemory.prototype.recordGame = function (moves, winner, opts) {
    opts = opts || {};
    var d = this._delta;
    for (var k = 0; k < moves.length; k++) {
      var mv = moves[k];
      var win = (winner === mv.color) ? 1 : 0;
      var p = this.patterns[mv.patKey] || (this.patterns[mv.patKey] = [0, 0]);
      p[0]++; p[1] += win;
      var dp = d.patterns[mv.patKey] || (d.patterns[mv.patKey] = [0, 0]);
      dp[0]++; dp[1] += win;

      if (mv.no <= 14 && mv.i >= 0) {
        var entry = this.book[mv.h] || (this.book[mv.h] = {});
        var em = entry[mv.i] || (entry[mv.i] = [0, 0]);
        em[0]++; em[1] += win;
        var de = d.book[mv.h] || (d.book[mv.h] = {});
        var dem = de[mv.i] || (de[mv.i] = [0, 0]);
        dem[0]++; dem[1] += win;
      }
    }
    if (opts.human) { this.meta.humanGames++; d.humanGames++; }
    else { this.meta.games++; d.games++; }
    this.meta.updated = Date.now();
    this.meta.lastResult = winner;
    this._scheduleFlush();
  };

  // 研习一局真实棋谱：和 recordGame 一样写棋型表与开局库，但单独计数，
  // 不冒充自我对弈局数，这样「研究录像」和「自己练」在面板上分得清。
  GoMemory.prototype.studyGame = function (moves, winner, opts) {
    opts = opts || {};
    var d = this._delta;
    var pass = opts.pass || 1;          // 第几遍研习
    var weight = opts.weight || 1;      // 同一遍里的权重（默认 1）
    for (var k = 0; k < moves.length; k++) {
      var mv = moves[k];
      var win = (winner === mv.color) ? 1 : 0;
      var p = this.patterns[mv.patKey] || (this.patterns[mv.patKey] = [0, 0]);
      p[0] += weight; p[1] += win * weight;
      var dp = d.patterns[mv.patKey] || (d.patterns[mv.patKey] = [0, 0]);
      dp[0] += weight; dp[1] += win * weight;

      if (mv.no <= 14 && mv.i >= 0) {
        var entry = this.book[mv.h] || (this.book[mv.h] = {});
        var em = entry[mv.i] || (entry[mv.i] = [0, 0]);
        em[0] += weight; em[1] += win * weight;
        var de = d.book[mv.h] || (d.book[mv.h] = {});
        var dem = de[mv.i] || (de[mv.i] = [0, 0]);
        dem[0] += weight; dem[1] += win * weight;
      }
    }
    // 这个方法每局棋谱调用一次，所以「遍数」只在每一遍的第一局计一次，
    // 否则局数一多，遍数就被算成「局次」（5 局走一遍会记成 5 遍）。
    if (pass !== this.meta.studyCountedPass) {
      this.meta.studyCountedPass = pass;
      this.meta.studyPasses = (this.meta.studyPasses || 0) + 1;
    }
    this.meta.studyMoves = (this.meta.studyMoves || 0) + moves.length;
    if (pass > (this.meta.studyBestPass || 0)) this.meta.studyBestPass = pass;
    this.meta.updated = Date.now();
    this._scheduleFlush();
  };

  GoMemory.prototype._scheduleFlush = function () {
    var self = this;
    if (this._flushTimer) return;
    this._flushTimer = setTimeout(function () {
      self._flushTimer = null;
      self.flush();
    }, 1200);
  };

  GoMemory.prototype.flush = function () {
    var self = this;
    var d = this._delta;
    if (!d.patterns || (Object.keys(d.patterns).length === 0 && d.games === 0 && d.humanGames === 0)) {
      return Promise.resolve();
    }
    this._resetDelta();
    return this._read().then(function (state) {
      state = state || { patterns: {}, book: {}, meta: {} };
      var pat = state.patterns || {};
      Object.keys(d.patterns).forEach(function (k) {
        var a = pat[k] || (pat[k] = [0, 0]);
        a[0] += d.patterns[k][0]; a[1] += d.patterns[k][1];
      });
      var book = state.book || {};
      Object.keys(d.book).forEach(function (h) {
        var e = book[h] || (book[h] = {});
        var src = d.book[h];
        Object.keys(src).forEach(function (m) {
          var a = e[m] || (e[m] = [0, 0]);
          a[0] += src[m][0]; a[1] += src[m][1];
        });
      });
      // 开局库控量，避免无限增长
      var keys = Object.keys(book);
      if (keys.length > BOOK_LIMIT) {
        for (var i = 0; i < keys.length - BOOK_LIMIT; i++) delete book[keys[i]];
      }
      var meta = Object.assign({}, state.meta || {});
      meta.games = (meta.games || 0) + d.games;
      meta.humanGames = (meta.humanGames || 0) + d.humanGames;
      // 研习计数只在内存里累加，这里按较大值回写，避免被覆盖丢进度。
      // 但棋谱库换了（studySig 不同）就是新的一轮研习，计数必须真的归零，
      // 否则 Math.max 会把上一批棋谱的旧遍数/手数一直顶在那里。
      var sameCorpus = (meta.studySig || '') === (self.meta.studySig || '');
      var storedAt = meta.studySigAt || 0;
      var selfAt = self.meta.studySigAt || 0;
      if (sameCorpus) {
        meta.studyPasses = Math.max(meta.studyPasses || 0, self.meta.studyPasses || 0);
        meta.studyMoves = Math.max(meta.studyMoves || 0, self.meta.studyMoves || 0);
        meta.studyBestPass = Math.max(meta.studyBestPass || 0, self.meta.studyBestPass || 0);
      } else if (selfAt >= storedAt) {
        // 自己这份是换谱后的新起点，清零必须真的写进去
        meta.studyPasses = self.meta.studyPasses || 0;
        meta.studyMoves = self.meta.studyMoves || 0;
        meta.studyBestPass = self.meta.studyBestPass || 0;
        meta.studySig = self.meta.studySig || '';
        meta.studySigAt = selfAt;
      }
      // 其余情况：存盘里的 sig 更新（另一个 worker 已经重算过），保留存盘值
      meta.updated = Date.now();
      if (d.lastResult !== null) meta.lastResult = d.lastResult;
      meta.version = 1;

      self.patterns = pat;
      self.book = book;
      self.meta = meta;
      return self._write({ patterns: pat, book: book, meta: meta });
    });
  };

  // 读取最新记忆（自对弈 worker 在后台写入后，页面端同步用）
  GoMemory.prototype.reload = function () {
    var self = this;
    return this._read().then(function (state) {
      if (!state) return self;
      self.patterns = state.patterns || {};
      self.book = state.book || {};
      self.meta = Object.assign(self.meta, state.meta || {});
      return self;
    });
  };

  GoMemory.prototype.patternStat = function (key) {
    return this.patterns[key] || null;
  };

  // 棋型胜率先验（平滑）
  GoMemory.prototype.prior = function (key) {
    var p = this.patterns[key];
    if (!p) return 0.42; // 未知棋型：略高于随机，鼓励探索
    return (p[1] + 1.6) / (p[0] + 4);
  };

  GoMemory.prototype.bookMoves = function (hash) {
    return this.book[hash] || null;
  };

  GoMemory.prototype.stats = function () {
    var pats = Object.keys(this.patterns).length;
    var book = Object.keys(this.book).length;
    var games = this.meta.games || 0;
    var human = this.meta.humanGames || 0;
    return {
      games: games, humanGames: human, patterns: pats, book: book,
      entries: pats + book, updated: this.meta.updated || 0,
      studyPasses: this.meta.studyPasses || 0,
      studyMoves: this.meta.studyMoves || 0,
      studyBestPass: this.meta.studyBestPass || 0
    };
  };

  /* ---------------- 段位阶段存档 ---------------- */

  GoMemory.prototype._stageLocalKey = DB_NAME + ':stages';

  GoMemory.prototype.listStages = function () {
    var self = this;
    if (!this._db) {
      try {
        if (!global.localStorage) return Promise.resolve([]);
        var arr = JSON.parse(global.localStorage.getItem(this._stageLocalKey) || '[]');
        return Promise.resolve(Array.isArray(arr) ? arr : []);
      } catch (e) { return Promise.resolve([]); }
    }
    return new Promise(function (resolve) {
      var tx = self._db.transaction(STAGE_STORE, 'readonly');
      var req = tx.objectStore(STAGE_STORE).getAll();
      req.onsuccess = function () {
        var list = (req.result || []).slice();
        list.sort(function (a, b) { return (a.ts || 0) - (b.ts || 0); });
        resolve(list);
      };
      req.onerror = function () { resolve([]); };
    });
  };

  // 进入新阶段时，把上一阶段的记忆冻成一份存档
  GoMemory.prototype.saveStage = function (info) {
    var self = this;
    var rec = {
      key: info.key,
      index: info.index,
      name: info.name,
      games: info.games,
      patterns: info.patterns,
      book: info.book,
      ts: info.ts || Date.now()
    };

    if (!this._db) {
      try {
        if (!global.localStorage) return Promise.resolve();
        var list = [];
        try { list = JSON.parse(global.localStorage.getItem(this._stageLocalKey) || '[]'); } catch (e) { list = []; }
        list.push(rec);
        while (list.length > 30) list.shift();
        global.localStorage.setItem(this._stageLocalKey, JSON.stringify(list));
      } catch (e) { /* 配额不足就放弃 */ }
      return Promise.resolve();
    }

    return new Promise(function (resolve) {
      var tx = self._db.transaction([STAGE_STORE, SNAP_STORE], 'readwrite');
      tx.objectStore(STAGE_STORE).put(rec);
      tx.objectStore(SNAP_STORE).put({ patterns: self.patterns, book: self.book }, rec.key);
      tx.oncomplete = function () {
        self._trimSnapshots().then(resolve, resolve);
      };
      tx.onerror = function () { resolve(); };
    });
  };

  GoMemory.prototype._trimSnapshots = function () {
    var self = this;
    if (!this._db) return Promise.resolve();
    return new Promise(function (resolve) {
      var tx = self._db.transaction(STAGE_STORE, 'readonly');
      var req = tx.objectStore(STAGE_STORE).getAll();
      req.onsuccess = function () {
        var list = (req.result || []).slice().sort(function (a, b) { return (a.ts || 0) - (b.ts || 0); });
        var drop = list.slice(0, Math.max(0, list.length - STAGE_FULL_KEEP))
          .map(function (r) { return r.key; });
        if (!drop.length) { resolve(); return; }
        var tx2 = self._db.transaction(SNAP_STORE, 'readwrite');
        var store = tx2.objectStore(SNAP_STORE);
        drop.forEach(function (k) { store.delete(k); });
        tx2.oncomplete = function () { resolve(); };
        tx2.onerror = function () { resolve(); };
      };
      req.onerror = function () { resolve(); };
    });
  };

  // 读取某个阶段存档的完整记忆（以后可用于回滚棋力）
  GoMemory.prototype.loadStage = function (key) {
    var self = this;
    if (!this._db) return Promise.resolve(null);
    return new Promise(function (resolve) {
      var tx = self._db.transaction(SNAP_STORE, 'readonly');
      var req = tx.objectStore(SNAP_STORE).get(key);
      req.onsuccess = function () { resolve(req.result || null); };
      req.onerror = function () { resolve(null); };
    });
  };

  GoMemory.prototype.clear = function () {
    var self = this;
    this.patterns = {};
    this.book = {};
    this.meta = { games: 0, updated: Date.now(), version: 1, humanGames: 0, lastResult: null };
    this._resetDelta();

    if (!this._db) {
      try { if (global.localStorage) global.localStorage.removeItem(this._stageLocalKey); } catch (e) { }
      return this._write({ patterns: {}, book: {}, meta: this.meta });
    }

    return this._write({ patterns: {}, book: {}, meta: this.meta }).then(function () {
      return new Promise(function (resolve) {
        var tx = self._db.transaction([STAGE_STORE, SNAP_STORE], 'readwrite');
        tx.objectStore(STAGE_STORE).clear();
        tx.objectStore(SNAP_STORE).clear();
        tx.oncomplete = function () { resolve(); };
        tx.onerror = function () { resolve(); };
      });
    });
  };

  var api = { GoMemory: GoMemory, patternKey: patternKey };
  global.GoMemoryLib = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
