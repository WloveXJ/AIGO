/*
 * trainer.worker.js —— 后台「研习 + 自我对弈」
 *  · 研习：把五局真实棋谱（四段录像还原 + 一本棋谱书录入）反复过一遍，写进棋型表与开局库
 *  · 自对弈：继续下棋、继续累积，棋型统计越来越准
 * 训练只在软件窗口打开时运行，窗口最小化暂停、关闭立即停止。
 */
importScripts('./go-engine.js', './memory-store.js', './ai-engine.js', './study-games.js');

var GoGame = GoEngine.GoGame;
var patternKey = GoMemoryLib.patternKey;
var Study = self.GoStudy;
var mem = new GoMemoryLib.GoMemory();
var ai = null;
var running = true;
var size = 19;
var movetime = 100;
var sessionGames = 0;
var speedWindow = [];   // 最近完成时间戳，用于估算速度

var BASE_PASSES = 8;    // 开局先研习 8 遍（反复研究录像）
var MAX_PASSES = 60;    // 之后每练 12 局补研习 1 遍，最多 60 遍
var STUDY_EVERY = 12;

function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

function post(msg, transfer) { self.postMessage(msg, transfer || []); }

function stats() { return mem.stats(); }

// 把一局棋谱重放成「棋型 -> 这一手的胜负」序列
function entriesOf(game) {
  var g = new GoGame(19, { komi: 3.75 });
  var moves = [];
  for (var k = 0; k < game.moves.length; k++) {
    var mv = game.moves[k];
    if (mv < 0) { g.pass(); continue; }
    if (g.board[mv] !== 0) break;
    var color = g.current;
    var rec = {
      i: mv, color: color, no: g.moveCount + 1,
      patKey: patternKey(g, mv, color),
      h: g.hash()
    };
    if (!g.play(mv).ok) break;
    moves.push(rec);
  }
  return moves;
}

// 研习一遍全部棋谱
async function studyPass() {
  var round = (mem.meta.studyPasses || 0) + 1;
  var played = 0;
  for (var i = 0; i < Study.GAMES.length; i++) {
    if (!running) return false;
    var gm = Study.GAMES[i];
    var entries = entriesOf(gm);
    mem.studyGame(entries, gm.winner, { pass: round });
    played += entries.length;
    post({
      type: 'study', round: round, game: gm.title,
      moves: entries.length, total: played,
      stats: stats()
    });
    await sleep(30);
  }
  await mem.flush();
  post({ type: 'studyDone', round: round, stats: stats() });
  return true;
}

async function playOne() {
  var game = new GoGame(size, { komi: 3.75 });
  var moves = [];
  var maxMoves = Math.floor(size * size * 1.6);
  var guard = 0;

  while (!game.gameOver && game.moveCount < maxMoves && guard++ < maxMoves * 2) {
    // 暂停 / 关闭窗口时立刻中断，不留半局垃圾数据
    if (!running) return false;
    var color = game.current;
    var res = ai.chooseMove(game, { timeMs: movetime });
    var mv = res.move;
    moves.push({
      i: mv, color: color, no: game.moveCount + 1,
      patKey: mv >= 0 ? patternKey(game, mv, color) : -1,
      h: game.hash()
    });
    if (mv === -1) game.pass(); else game.play(mv);
  }

  var s = game.areaScore();
  var winner = s.black > s.line ? 1 : (s.white > s.whiteLine ? 2 : 0);
  mem.recordGame(moves, winner);
  await mem.flush();

  sessionGames++;
  var now = Date.now();
  speedWindow.push(now);
  while (speedWindow.length && now - speedWindow[0] > 45000) speedWindow.shift();

  post({
    type: 'progress',
    stats: stats(),
    size: size,
    sessionGames: sessionGames,
    last: { moves: moves.length, winner: winner, black: s.black, white: s.white },
    speed: speedWindow.length * (60 / 45)  // 45 秒窗口 → 折算成局/分钟
  });
  return true;
}

async function loop() {
  await mem.init();

  // 棋谱库有更新（新增/扩谱）时，把研习进度清零，重新从头反复研究。
  // 前缀 v2 用来在「遍数算法」本身改动后也重算一次，避免留着旧口径的数字。
  var sig = 'v2:' + Study.GAMES.length + ':' + Study.GAMES.reduce(function (a, g) { return a + g.moves.length; }, 0);
  if (mem.meta.studySig !== sig) {
    mem.meta.studySig = sig;
    mem.meta.studySigAt = Date.now();
    mem.meta.studyPasses = 0;
    mem.meta.studyMoves = 0;
    mem.meta.studyCountedPass = 0;
    await mem.flush();
  }

  ai = new GoAI(mem, { timeMs: movetime, temperature: 0.5, cPuct: 1.6 });
  post({ type: 'ready', stats: stats() });

  // 先把真实棋谱反复研习一遍，再开始自我对弈
  var guard = 0;
  while (running && (mem.meta.studyPasses || 0) < BASE_PASSES && guard++ < MAX_PASSES) {
    await studyPass();
  }

  var sinceStudy = 0;
  while (true) {
    if (!running) { await sleep(200); continue; }
    try {
      await playOne();
      sinceStudy++;
      if (sinceStudy >= STUDY_EVERY && (mem.meta.studyPasses || 0) < MAX_PASSES) {
        sinceStudy = 0;
        await studyPass();
      }
    } catch (err) {
      post({ type: 'error', message: String(err) });
      await sleep(800);
    }
    await sleep(120);
  }
}

self.onmessage = function (e) {
  var d = e.data || {};
  if (d.type === 'pause') running = false;
  else if (d.type === 'resume') running = true;
  else if (d.type === 'config') {
    if (d.size) size = d.size;
    if (d.movetime) movetime = d.movetime;
    if (ai) { ai.timeMs = movetime; }
  } else if (d.type === 'flush') {
    mem.flush().then(function () { post({ type: 'progress', stats: stats() }); });
  } else if (d.type === 'study') {
    // 手动「再研习一遍」
    var n = d.passes || 1;
    (async function () {
      for (var i = 0; i < n; i++) {
        if (!running) break;
        if ((mem.meta.studyPasses || 0) >= MAX_PASSES) break;
        await studyPass();
      }
    })();
  } else if (d.type === 'reset') {
    mem.clear().then(function () { post({ type: 'progress', stats: stats(), speed: 0, sessionGames: 0 }); });
  }
};

loop();
