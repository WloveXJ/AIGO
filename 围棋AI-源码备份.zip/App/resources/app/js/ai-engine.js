/*
 * ai-engine.js —— 本地围棋 AI
 *  - MCTS（PUCT）：选择 / 扩展 / 模拟 / 回传
 *  - 先验来自"记忆"里的 3x3 棋型胜率表 + 开局库（自我对弈累积）
 *  - 纯前端运行，无外部依赖
 */
(function (global) {
  'use strict';

  var Engine = (typeof require !== 'undefined' && typeof module !== 'undefined')
    ? require('./go-engine.js') : global.GoEngine;
  var MemoryLib = (typeof require !== 'undefined' && typeof module !== 'undefined')
    ? require('./memory-store.js') : global.GoMemoryLib;

  var BLACK = 1, WHITE = 2, EMPTY = 0;
  var patternKey = MemoryLib.patternKey;

  function opp(c) { return c === BLACK ? WHITE : BLACK; }

  function Node(move, parent, toMove) {
    this.move = move;
    this.parent = parent;
    this.toMove = toMove;
    this.children = [];
    this.untried = null;
    this.visits = 0;
    this.wins = 0;
    this.prior = 0.3;
  }

  function GoAI(memory, opts) {
    opts = opts || {};
    this.mem = memory || null;
    this.timeMs = typeof opts.timeMs === 'number' ? opts.timeMs : 900;
    this.cPuct = typeof opts.cPuct === 'number' ? opts.cPuct : 1.6;
    this.maxIters = opts.maxIters || 60000;
    this.temperature = typeof opts.temperature === 'number' ? opts.temperature : 0;
    this.rootCap = opts.rootCap || 0; // 0 = 自动
    // 棋风（吴棋 / 邓棋镜像）：profile 决定先验口味，book 决定开局照谁走
    this.style = opts.style || null;
    this.styleBook = opts.styleBook || null;
    this.styleName = opts.styleName || '';
    this.styleStrength = typeof opts.styleStrength === 'number' ? opts.styleStrength : 0;
    this.tactics = opts.tactics !== false;
    this._bookHit = 0;
  }

  // 切换棋风（不重建实例，避免训练中断）
  GoAI.prototype.setStyle = function (style) {
    style = style || {};
    this.style = style.profile || null;
    this.styleBook = style.book || null;
    this.styleName = style.name || '';
    this.styleStrength = typeof style.strength === 'number' ? style.strength : (this.style ? 1 : 0);
    return this;
  };

  // 战术先验：能提子 / 会被自紧气 / 能叫吃，都会明显影响这一手的价值
  GoAI.prototype.tacticMul = function (game, i, color) {
    if (!this.tactics) return 1;
    var b = game.board, adj = game.adj[i];
    if (!adj) return 1;
    var opp = color === BLACK ? WHITE : BLACK;
    var capture = 0, selfAtari = false, checkEnemy = 0, ownNb = 0;
    for (var k = 0; k < adj.length; k++) {
      var q = adj[k], v = b[q];
      if (v === EMPTY) continue;
      if (v === opp) {
        var ge = game.group(q);
        if (ge.libs.length === 1) capture += ge.stones.length;
        else if (ge.libs.length === 2) checkEnemy++;
      } else {
        ownNb++;
        var go = game.group(q);
        // 只差这一口气：落下去就剩 1 气（除非同时提子）
        if (go.libs.length === 2 && go.libs.indexOf(i) >= 0) selfAtari = true;
      }
    }
    var m = 1;
    if (capture > 0) {
      m *= 1 + Math.min(0.85, 0.30 * Math.sqrt(capture));
      if (capture >= 3) m *= 1.12;
    } else if (selfAtari) {
      m *= 0.30;
    }
    if (checkEnemy > 0 && capture === 0) m *= 1 + Math.min(0.18, 0.07 * checkEnemy);
    if (ownNb > 0 && capture === 0 && !selfAtari) m *= 1.04;
    return m;
  };

  GoAI.prototype.candidateCap = function (game) {
    if (this.rootCap) return this.rootCap;
    return game.size >= 19 ? 46 : (game.size >= 13 ? 56 : 999);
  };

  // 先验：棋型胜率 + 局部性 + 开局库
  GoAI.prototype.priorFor = function (game, i, color) {
    if (i < 0) return 0.06;
    var p = 0.42;
    if (this.mem) {
      p = this.mem.prior(patternKey(game, i, color));
    }
    // 局部性：靠近上一手
    var local = 0.5;
    if (game.lastMove >= 0) {
      var ax = i % game.size, ay = (i / game.size) | 0;
      var bx = game.lastMove % game.size, by = (game.lastMove / game.size) | 0;
      var d = Math.abs(ax - bx) + Math.abs(ay - by);
      local = d <= 1 ? 1 : d <= 2 ? 0.78 : d <= 4 ? 0.58 : 0.42;
    }
    // 开局偏好三四线
    var x = i % game.size, y = (i / game.size) | 0;
    var edgePenalty = 1;
    var minEdge = Math.min(x, y, game.size - 1 - x, game.size - 1 - y);
    if (game.moveCount < 10) edgePenalty = minEdge === 0 ? 0.55 : (minEdge === 1 ? 1.05 : 1);

    // 布局阶段：三四线优先、角落优先，别一上来就下中腹
    if (game.moveCount < 30) {
      var LINE_W = [0.35, 0.55, 1.12, 1.25, 1.02, 0.86, 0.72, 0.6, 0.5, 0.42];
      edgePenalty *= LINE_W[Math.min(9, minEdge)];
      var nearX = Math.min(x, game.size - 1 - x), nearY = Math.min(y, game.size - 1 - y);
      if (nearX <= 4 && nearY <= 4) edgePenalty *= 1.28;
      else if (nearX <= 2 || nearY <= 2) edgePenalty *= 1.12;
    }

    var prior = (0.68 * p + 0.32 * local) * edgePenalty;

    // 开局库加成
    if (this.mem && game.moveCount <= 14) {
      var bk = this.mem.bookMoves(game.hash());
      if (bk && bk[i]) {
        var b = bk[i];
        var rate = (b[1] + 1) / (b[0] + 2);
        prior = prior * 0.55 + rate * 0.45;
      }
    }

    // 棋风手册：录像里这一方在同样局面下走过这一手，就明确照着走
    if (this.styleBook) {
      var sb = this.styleBook[game.hash() + '|' + color];
      if (sb && sb[i]) {
        prior = prior * 0.32 + 0.68;
        this._bookHit++;
      }
    }

    // 棋风口味：喜欢几线、角/边/中腹、手距远近
    if (this.style && this.styleStrength > 0) {
      var StudyLib = (typeof require !== 'undefined' && typeof module !== 'undefined')
        ? require('./study-games.js') : global.GoStudy;
      if (StudyLib) prior *= StudyLib.priorMul(this.style, game.size, i, game.lastMove, this.styleStrength);
    }

    // 战术：提子 / 自紧气 / 叫吃
    prior *= this.tacticMul(game, i, color);

    return Math.max(0.01, Math.min(0.99, prior));
  };

  GoAI.prototype.genCandidates = function (game, toMove) {
    var list = game.candidates(2);
    var size = game.size, b = game.board;
    var lateGame = game.moveCount > game.N * 0.62;
    var opp = toMove === BLACK ? WHITE : BLACK;
    var scored = [];
    for (var k = 0; k < list.length; k++) {
      var i = list[k];
      if (b[i] !== EMPTY) continue;
      if (game.isEyeFill(i, toMove)) continue;
      // 官子阶段只考虑贴着对方棋子的点：中国规则下往自己空里填子不涨分，
      // 但会让自对弈学出一堆废棋，这里直接掐掉
      if (lateGame) {
        var x = i % size, y = (i / size) | 0, nearOpp = false;
        for (var dy = -2; dy <= 2 && !nearOpp; dy++) {
          for (var dx = -2; dx <= 2; dx++) {
            var nx = x + dx, ny = y + dy;
            if (nx < 0 || nx >= size || ny < 0 || ny >= size) continue;
            if (b[ny * size + nx] === opp) { nearOpp = true; break; }
          }
        }
        if (!nearOpp) continue;
      }
      scored.push({ i: i, p: this.priorFor(game, i, toMove) });
    }
    scored.sort(function (a, b2) { return b2.p - a.p; });
    var cap = this.candidateCap(game);
    var out = [];
    for (var s = 0; s < scored.length && s < cap; s++) out.push(scored[s].i);
    // 布局后期允许 AI 选择弃权
    if (game.moveCount > game.N * 0.55) out.push(-1);
    return out;
  };

  GoAI.prototype.sampleUntried = function (game, node) {
    var list = node.untried;
    if (!list || list.length === 0) return null;
    // 按先验做二元锦标赛抽样，前几次迭代更倾向高先验点
    var idx = (Math.random() * list.length) | 0;
    if (list.length > 1 && Math.random() < 0.6) {
      var idx2 = (Math.random() * list.length) | 0;
      var p1 = this.priorFor(game, list[idx], node.toMove);
      var p2 = this.priorFor(game, list[idx2], node.toMove);
      if (p2 > p1) idx = idx2;
    }
    var mv = list[idx];
    list.splice(idx, 1);
    return mv;
  };

  GoAI.prototype.bestChild = function (node, rootColor) {
    var best = null, bestScore = -1e18;
    var logN = Math.log(node.visits + 1);
    for (var i = 0; i < node.children.length; i++) {
      var c = node.children[i];
      var q = c.visits > 0 ? c.wins / c.visits : 0.5;
      var v = (node.toMove === rootColor) ? q : 1 - q;
      var u = this.cPuct * c.prior * Math.sqrt(logN) / (1 + c.visits);
      var s = v + u;
      if (s > bestScore) { bestScore = s; best = c; }
    }
    return best;
  };

  GoAI.prototype.playMove = function (game, move) {
    if (move === -1) return game.pass();
    return game.play(move);
  };

  GoAI.prototype.rollout = function (game, rootColor) {
    var cap = game.N * 2;
    var played = 0, passes = 0;
    var empties = [];
    for (var i = 0; i < game.N; i++) if (game.board[i] === EMPTY) empties.push(i);
    if (empties.length === 0) return { value: 0.5, plays: 0 };

    while (played < cap && !game.gameOver) {
      var mv = -1;
      for (var t = 0; t < 14; t++) {
        var p = empties[(Math.random() * empties.length) | 0];
        if (game.board[p] !== EMPTY) continue;
        if (game.isEyeFill(p, game.current)) continue;
        mv = p; break;
      }
      if (mv < 0) {
        game.pass(); played++; passes++;
        if (passes >= 2) break;
        continue;
      }
      var r = game.play(mv);
      if (!r.ok) {
        var ok = false;
        for (var t2 = 0; t2 < 6; t2++) {
          var p2 = empties[(Math.random() * empties.length) | 0];
          if (game.board[p2] !== EMPTY) continue;
          var r2 = game.play(p2);
          if (r2.ok) { ok = true; played++; passes = 0; break; }
        }
        if (!ok) {
          game.pass(); played++; passes++;
          if (passes >= 2) break;
        }
      } else {
        played++; passes = 0;
      }
    }

    var s = game.areaScore();
    var diff = (rootColor === BLACK) ? (s.black - s.line) : (s.white - s.whiteLine);
    var scale = game.N * 0.09;
    var value = 1 / (1 + Math.exp(-diff / scale));
    return { value: value, plays: played };
  };

  // 主入口
  GoAI.prototype.chooseMove = function (game, opts) {
    opts = opts || {};
    var timeMs = typeof opts.timeMs === 'number' ? opts.timeMs : this.timeMs;
    var rootColor = game.current;
    var startTs = Date.now();

    // 棋风手册：这一方在录像里走过这个局面，就直接照着走（镜像模式的核心）
    if (this.styleBook && !opts.noBook) {
      var bk = this.styleBook[game.hash() + '|' + rootColor];
      if (bk) {
        // 同一局面在录像里可能有多手下法：并列时随机选一个，别每次都一模一样
        var cands = [], bestN = 0;
        for (var kk in bk) {
          var kIdx = +kk;
          if (game.board[kIdx] !== EMPTY) continue;
          if (bk[kk] > bestN) { bestN = bk[kk]; cands = [kIdx]; }
          else if (bk[kk] === bestN) cands.push(kIdx);
        }
        var bid = cands.length ? cands[(Math.random() * cands.length) | 0] : -1;
        if (bid >= 0 && game.board[bid] === EMPTY) {
          this._bookHit++;
          return {
            move: bid, visits: 0, winrate: 0.5, iterations: 0,
            elapsed: Date.now() - startTs, book: true,
            alternatives: []
          };
        }
      }
    }

    var root = new Node(-1, null, rootColor);
    root.untried = this.genCandidates(game, rootColor);

    if (root.untried.length === 0) {
      return { move: -1, visits: 0, winrate: 0.5, iterations: 0, elapsed: 0 };
    }

    var deadline = startTs + timeMs;
    var iterations = 0;

    while (Date.now() < deadline && iterations < this.maxIters) {
      iterations++;
      var node = root, path = [root], undoCount = 0, expandDone = false;

      // 选择 + 扩展
      while (true) {
        if (node.untried === null) node.untried = this.genCandidates(game, node.toMove);
        var expanded = false;
        var guard = 0;
        while (node.untried.length > 0 && guard++ < 60) {
          var mv = this.sampleUntried(game, node);
          if (mv === null) break;
          var prior = this.priorFor(game, mv, node.toMove);
          var r = this.playMove(game, mv);
          if (!r.ok) continue;
          undoCount++;
          var child = new Node(mv, node, opp(node.toMove));
          child.prior = prior;
          node.children.push(child);
          node = child; path.push(child);
          expanded = true;
          break;
        }
        if (expanded) { expandDone = true; break; }
        if (node.children.length === 0) break;
        var best = this.bestChild(node, rootColor);
        if (!best) break;
        var r2 = this.playMove(game, best.move);
        if (!r2.ok) break;
        undoCount++;
        node = best; path.push(node);
      }

      // 模拟
      var sim = this.rollout(game, rootColor);
      undoCount += sim.plays;
      var value = sim.value;

      // 回传
      for (var pi = 0; pi < path.length; pi++) {
        path[pi].visits++;
        path[pi].wins += value;
      }

      // 还原棋盘
      for (var u = 0; u < undoCount; u++) game.undo();
    }

    if (root.children.length === 0) {
      return { move: -1, visits: 0, winrate: 0.5, iterations: iterations, elapsed: Date.now() - startTs };
    }

    var pick;
    if (this.temperature > 0.01) {
      var total = 0, arr = [];
      for (var c = 0; c < root.children.length; c++) {
        var w = Math.pow(root.children[c].visits + 1, 1 / this.temperature);
        total += w; arr.push({ c: root.children[c], w: w });
      }
      var rnd = Math.random() * total, acc = 0;
      pick = root.children[0];
      for (var a = 0; a < arr.length; a++) {
        acc += arr[a].w;
        if (rnd <= acc) { pick = arr[a].c; break; }
      }
    } else {
      pick = root.children[0];
      for (var b = 0; b < root.children.length; b++) {
        if (root.children[b].visits > pick.visits) pick = root.children[b];
      }
    }

    var q = pick.visits ? pick.wins / pick.visits : 0.5;
    return {
      move: pick.move,
      visits: pick.visits,
      winrate: q,
      iterations: iterations,
      elapsed: Date.now() - startTs,
      alternatives: root.children.slice().sort(function (x, y) { return y.visits - x.visits; }).slice(0, 5)
        .map(function (n) { return { move: n.move, visits: n.visits, winrate: n.visits ? n.wins / n.visits : 0.5 }; })
    };
  };

  // 训练用：下完一整局并返回棋谱
  GoAI.prototype.selfPlayGame = function (size, maxMoves, movetime) {
    var EngineLib = Engine;
    var game = new EngineLib.GoGame(size);
    var moves = [];
    var guards = 0;
    while (!game.gameOver && game.moveCount < maxMoves && guards++ < maxMoves * 2) {
      var color = game.current;
      var res = this.chooseMove(game, { timeMs: movetime });
      var mv = res.move;
      var entry = {
        i: mv, color: color, no: game.moveCount + 1,
        patKey: mv >= 0 ? patternKey(game, mv, color) : -1,
        h: game.hash()
      };
      moves.push(entry);
      if (mv === -1) game.pass(); else game.play(mv);
    }
    var s = game.areaScore();
    var winner = s.black > s.line ? BLACK : (s.white > s.whiteLine ? WHITE : 0);
    return { moves: moves, winner: winner, board: game.board, size: size, moveCount: game.moveCount, score: s };
  };

  var api = { GoAI: GoAI, Node: Node };
  global.GoAI = GoAI;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
