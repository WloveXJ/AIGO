/*
 * analysis.js —— 形势判断 / 数子辅助 / 胜率换算
 *  - buildField：影响场（influence field）。棋子和空点做带超松弛的调和扩散，
 *    空点最后收敛到"离哪边更近"，用来判断每一点的归属倾向。
 *  - estimate：活子 + 围空 + 公气各半，得到双方子数、子差、胜率、弱棋块。
 *  - winrateOf：子差 → 胜率（logistic），尺度随棋盘大小变化。
 * 纯前端、无依赖，UI 与 AI 共用。
 */
(function (global) {
  'use strict';

  var BLACK = 1, WHITE = 2, EMPTY = 0;

  // 影响场：stones 固定 ±1，空点反复取邻点均值（高斯-赛德尔 + 超松弛，交替方向扫）
  function buildField(game, board, opts) {
    opts = opts || {};
    var N = game.N, adj = game.adj;
    var v = new Float32Array(N);
    for (var i = 0; i < N; i++) {
      var c = board[i];
      v[i] = c === BLACK ? 1 : c === WHITE ? -1 : 0;
    }
    var iters = opts.iters || (game.size >= 19 ? 110 : game.size >= 13 ? 85 : 60);
    var omega = 1.72;
    for (var it = 0; it < iters; it++) {
      var fwd = (it & 1) === 0;
      for (var k = 0; k < N; k++) {
        var p = fwd ? k : N - 1 - k;
        if (board[p] !== EMPTY) continue;
        var ns = adj[p], s = 0;
        for (var t = 0; t < ns.length; t++) s += v[ns[t]];
        var nv = v[p] + omega * (s / ns.length - v[p]);
        v[p] = nv > 1 ? 1 : (nv < -1 ? -1 : nv);
      }
    }
    return v;
  }

  function winrateOf(margin, N) {
    var k = Math.max(2.4, 4.2 * N / 361);
    var w = 1 / (1 + Math.exp(-margin / k));
    return Math.max(0.02, Math.min(0.98, w));
  }

  // 形势判断主函数
  // opts.dead: 死子集合（结算阶段传入）；opts.threshold: 归属阈值
  function estimate(game, opts) {
    opts = opts || {};
    var N = game.N, size = game.size;
    var base = opts.board || game.board;
    var dead = opts.dead || null;

    var b = base;
    if (dead && dead.size) {
      b = Int8Array.from(base);
      dead.forEach(function (i) { if (i >= 0 && i < N) b[i] = EMPTY; });
    }

    var field = buildField(game, b, opts);
    var TH = typeof opts.threshold === 'number' ? opts.threshold : 0.14;

    var blackStones = 0, whiteStones = 0;
    for (var i = 0; i < N; i++) {
      if (b[i] === BLACK) blackStones++;
      else if (b[i] === WHITE) whiteStones++;
    }

    var terr = new Int8Array(N);
    var blackTerr = 0, whiteTerr = 0, dame = 0;
    var claimB = [], claimW = [];
    for (var p = 0; p < N; p++) {
      if (b[p] !== EMPTY) continue;
      var f = field[p];
      if (f > TH) { terr[p] = BLACK; blackTerr++; claimB.push({ i: p, s: f }); }
      else if (f < -TH) { terr[p] = WHITE; whiteTerr++; claimW.push({ i: p, s: -f }); }
      else dame++;
    }

    // 认地强度：棋子越少，围空越不"算数"。
    // 同一个系数既决定折算比例，也决定棋盘上画多少个方块，
    // 保证"看到的"和"算到的"完全一致；开局几乎不标，终局才铺满。
    var stones = blackStones + whiteStones;
    var density = Math.min(1, stones / (N * 0.5));
    var conf = Math.min(1, stones / (N * 0.11));
    var claim = Math.pow(density, 0.85) * conf;
    if (claim < 1) {
      claimB.sort(function (x, y) { return y.s - x.s; });
      claimW.sort(function (x, y) { return y.s - x.s; });
      // 认地强度太低（开局阶段）就一个方块都不画，别让人误会
      var show = claim >= 0.06;
      var keepB = show ? Math.round(claimB.length * claim) : 0;
      var keepW = show ? Math.round(claimW.length * claim) : 0;
      for (var kb = keepB; kb < claimB.length; kb++) terr[claimB[kb].i] = EMPTY;
      for (var kw = keepW; kw < claimW.length; kw++) terr[claimW[kw].i] = EMPTY;
      blackTerr = keepB;
      whiteTerr = keepW;
    }
    var bTerr = blackTerr;
    var wTerr = whiteTerr;
    var dameEff = N - stones - bTerr - wTerr;
    var half = dameEff * 0.5;
    var black = blackStones + bTerr + half;
    var white = whiteStones + wTerr + half;
    var line = N / 2 + game.komi;   // 黑胜线
    var whiteLine = N - line;       // 白胜线

    // 子差：以黑胜线为基准，正数黑领先（中国规则下"需超出胜线"的部分）
    // 棋子很少时判断不可靠，向 0 收敛；40 子（19 路）后完全采信。
    var lead = (black - line) * conf;
    var margin = lead;
    var blackWinrate = winrateOf(margin, N);

    // 弱棋块：气 ≤ 2 的棋块
    var danger = new Int8Array(N);
    var weak = [];
    if (!(dead && dead.size)) {
      var seen = new Uint8Array(N);
      for (var s = 0; s < N; s++) {
        if (b[s] === EMPTY || seen[s]) continue;
        var g = game.group(s);
        for (var t = 0; t < g.stones.length; t++) seen[g.stones[t]] = 1;
        if (g.libs.length <= 2) {
          var lv = g.libs.length === 1 ? 2 : 1;
          for (var t2 = 0; t2 < g.stones.length; t2++) danger[g.stones[t2]] = lv;
          weak.push({ stones: g.stones.slice(), libs: g.libs.length, color: b[s] });
        }
      }
    }

    var winner = 0, diff = 0;
    if (black > line) { winner = BLACK; diff = black - line; }
    else if (white > whiteLine) { winner = WHITE; diff = white - whiteLine; }

    return {
      field: field,
      territory: terr,
      danger: danger,
      weak: weak,
      black: black, white: white,
      blackStones: blackStones, whiteStones: whiteStones,
      blackTerr: bTerr,
      whiteTerr: wTerr,
      dame: dameEff,
      dameRaw: dame,
      claim: claim,
      line: line, whiteLine: whiteLine,
      lead: lead, margin: margin,
      winner: winner, diff: diff,
      blackWinrate: blackWinrate,
      deadCount: dead ? dead.size : 0
    };
  }

  // 把子数差写成一句人话
  function leadText(ev) {
    var v = ev.lead;
    if (Math.abs(v) < 0.6) return '形势接近';
    return (v > 0 ? '黑' : '白') + '胜 ' + Math.abs(v).toFixed(1) + ' 子';
  }

  var api = { buildField: buildField, estimate: estimate, winrateOf: winrateOf, leadText: leadText };
  global.GoAnalysis = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
