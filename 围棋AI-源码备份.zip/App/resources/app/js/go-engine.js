/*
 * go-engine.js —— 围棋规则引擎
 * 严格实现 go_simple_cn_for_game_v2：
 *  - 气 / 提子 / 禁着点（试下→先提→后查）/ 打劫 / 连续 pass 终局
 *  - 中国数子：活子 + 围空 + 公气各 0.5 子，黑贴 3.75 子
 *  - 终局死子标记与真眼判断
 */
(function (global) {
  'use strict';

  var EMPTY = 0, BLACK = 1, WHITE = 2;

  function otherColor(c) { return c === BLACK ? WHITE : BLACK; }

  // 固定种子的伪随机，保证 zobrist 跨会话稳定
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  var zobristCache = {};
  function getZobrist(size) {
    if (zobristCache[size]) return zobristCache[size];
    var rnd = mulberry32(0x9E3779B1 ^ (size * 2654435761));
    var n = size * size;
    var t = { b: new Int32Array(n), w: new Int32Array(n) };
    for (var i = 0; i < n; i++) {
      t.b[i] = (rnd() * 0xFFFFFFFF) | 0;
      t.w[i] = (rnd() * 0xFFFFFFFF) | 0;
    }
    zobristCache[size] = t;
    return t;
  }

  function GoGame(size, opts) {
    opts = opts || {};
    this.size = size || 19;
    this.N = this.size * this.size;
    this.komi = (typeof opts.komi === 'number') ? opts.komi : 3.75;
    this.board = new Int8Array(this.N);
    this.current = BLACK;
    this.koPoint = -1;
    this.consecutivePass = 0;
    this.gameOver = false;
    this.scoringPhase = false;
    this.dead = new Set();
    this.captures = { 1: 0, 2: 0 };
    this.moveCount = 0;
    this.lastMove = -1;
    this.result = null;

    // 邻接表
    this.adj = new Array(this.N);
    for (var y = 0; y < this.size; y++) {
      for (var x = 0; x < this.size; x++) {
        var i = y * this.size + x, arr = [];
        if (x > 0) arr.push(i - 1);
        if (x < this.size - 1) arr.push(i + 1);
        if (y > 0) arr.push(i - this.size);
        if (y < this.size - 1) arr.push(i + this.size);
        this.adj[i] = arr;
      }
    }

    this._markStone = new Int32Array(this.N);
    this._markLib = new Int32Array(this.N);
    this._stampS = 0;
    this._stampL = 0;
    this._stack = [];
    this._zob = getZobrist(this.size);
    this._hash = this._computeHash();
  }

  GoGame.prototype._computeHash = function () {
    var h = 2166136261 ^ this.size;
    var z = this._zob, b = this.board;
    for (var i = 0; i < this.N; i++) {
      var v = b[i];
      if (v === BLACK) h = (h ^ z.b[i]) | 0;
      else if (v === WHITE) h = (h ^ z.w[i]) | 0;
    }
    return h;
  };

  GoGame.prototype.hash = function () { return this.size + ':' + this._hash; };

  GoGame.prototype.idx = function (x, y) { return y * this.size + x; };
  GoGame.prototype.xy = function (i) { return { x: i % this.size, y: Math.floor(i / this.size) }; };

  // 取棋块：返回 {stones, libs}
  GoGame.prototype.group = function (start) {
    var color = this.board[start];
    var stones = [], libs = [];
    if (!color) return { stones: stones, libs: libs };
    var ss = ++this._stampS;
    var sl = ++this._stampL;
    var ms = this._markStone, ml = this._markLib;
    var b = this.board, adj = this.adj;
    var stack = [start];
    ms[start] = ss;
    while (stack.length) {
      var p = stack.pop();
      stones.push(p);
      var ns = adj[p];
      for (var k = 0; k < ns.length; k++) {
        var q = ns[k], v = b[q];
        if (v === EMPTY) {
          if (ml[q] !== sl) { ml[q] = sl; libs.push(q); }
        } else if (v === color && ms[q] !== ss) {
          ms[q] = ss; stack.push(q);
        }
      }
    }
    return { stones: stones, libs: libs };
  };

  GoGame.prototype.groupLibs = function (start) { return this.group(start).libs; };

  // 落子：试下 → 先提对方 → 后查自身 → 劫判定
  GoGame.prototype.play = function (i) {
    if (this.gameOver) return { ok: false, reason: 'game_over' };
    if (typeof i !== 'number' || i < 0 || i >= this.N) return { ok: false, reason: 'outside' };
    if (this.board[i] !== EMPTY) return { ok: false, reason: 'occupied' };
    if (i === this.koPoint) return { ok: false, reason: 'ko' };

    var color = this.current;
    var opp = otherColor(color);
    var b = this.board;

    b[i] = color; // 试下

    // 先提：对方所有无气棋块
    var captured = [];
    var ns = this.adj[i];
    for (var k = 0; k < ns.length; k++) {
      var q = ns[k];
      if (b[q] === opp) {
        var g = this.group(q);
        if (g.libs.length === 0) {
          for (var t = 0; t < g.stones.length; t++) {
            var s = g.stones[t];
            if (b[s] === opp) { b[s] = EMPTY; captured.push(s); }
          }
        }
      }
    }

    // 后查：自身无气且未提子 → 禁着点，回滚
    if (captured.length === 0) {
      var own = this.group(i);
      if (own.libs.length === 0) {
        b[i] = EMPTY;
        return { ok: false, reason: 'suicide' };
      }
    }

    // 劫判定：恰好提 1 子，且己方该块仅剩 1 口气（即被提位置）
    var newKo = -1;
    if (captured.length === 1) {
      var og = this.group(i);
      if (og.libs.length === 1 && og.libs[0] === captured[0]) newKo = captured[0];
    }

    this._stack.push({
      i: i, color: color, captured: captured, ko: this.koPoint,
      pass: this.consecutivePass, last: this.lastMove,
      over: this.gameOver
    });

    this.koPoint = newKo;
    this.consecutivePass = 0;
    this.current = opp;
    this.lastMove = i;
    this.moveCount++;
    this.captures[color] += captured.length;
    this._hash = this._computeHash();

    return { ok: true, captured: captured, ko: newKo };
  };

  // 弃权
  GoGame.prototype.pass = function () {
    if (this.gameOver) return { ok: false, reason: 'game_over' };
    this._stack.push({
      i: -1, color: this.current, captured: [], ko: this.koPoint,
      pass: this.consecutivePass, last: this.lastMove, over: this.gameOver
    });
    this.consecutivePass++;
    this.current = otherColor(this.current);
    this.lastMove = -1;
    if (this.consecutivePass >= 2) {
      this.gameOver = true;
      this.scoringPhase = true;
    }
    return { ok: true, gameOver: this.gameOver };
  };

  GoGame.prototype.undo = function () {
    var d = this._stack.pop();
    if (!d) return false;
    if (d.i >= 0) {
      this.board[d.i] = EMPTY;
      var oc = otherColor(d.color);
      for (var k = 0; k < d.captured.length; k++) this.board[d.captured[k]] = oc;
      this.captures[d.color] -= d.captured.length;
      this.moveCount--;
    }
    this.koPoint = d.ko;
    this.consecutivePass = d.pass;
    this.current = d.color;
    this.lastMove = d.last;
    this.gameOver = d.over;
    this.scoringPhase = false;
    this.result = null;
    this._hash = this._computeHash();
    return true;
  };

  // 眼位判断（单点真眼近似，按 JSON 的对角线规则）
  GoGame.prototype.isTrueEye = function (i, color) {
    if (this.board[i] !== EMPTY) return false;
    var x = i % this.size, y = Math.floor(i / this.size);
    var ns = this.adj[i];
    for (var k = 0; k < ns.length; k++) if (this.board[ns[k]] !== color) return false;

    var corners = [];
    if (y > 0 && x > 0) corners.push(this.idx(x - 1, y - 1));
    if (y > 0 && x < this.size - 1) corners.push(this.idx(x + 1, y - 1));
    if (y < this.size - 1 && x > 0) corners.push(this.idx(x - 1, y + 1));
    if (y < this.size - 1 && x < this.size - 1) corners.push(this.idx(x + 1, y + 1));

    var opp = otherColor(color);
    var oppCount = 0;
    for (var c = 0; c < corners.length; c++) if (this.board[corners[c]] === opp) oppCount++;

    // 角上 2 个对角点必须全为己方；边线 3 个全己方；中腹对方至多占 1 个
    if (corners.length <= 2) return oppCount === 0;
    if (corners.length === 3) return oppCount === 0;
    return oppCount <= 1;
  };

  // 是否"填自己的眼"（AI 与随机走子都要避开）
  GoGame.prototype.isEyeFill = function (i, color) {
    return this.isTrueEye(i, color);
  };

  // 星位 / 空角大场：19 路是 3-9-15，13 路 3-6-9，9 路 2-4-6
  var openingCache = {};
  function openingPoints(size) {
    if (openingCache[size]) return openingCache[size];
    var third = size >= 19 ? 3 : (size >= 13 ? 3 : 2);
    var c = (size - 1) / 2;
    var coords = [third, c, size - 1 - third];
    var out = [];
    for (var a = 0; a < 3; a++) {
      for (var b2 = 0; b2 < 3; b2++) {
        var x = Math.round(coords[a]), y = Math.round(coords[b2]);
        out.push(y * size + x);
      }
    }
    openingCache[size] = out;
    return out;
  }

  // 生成候选落点：已有棋子周围 2 格内 + 空角大场 + 空盘时的星位与中腹
  GoGame.prototype.candidates = function (radius) {
    radius = radius || 2;
    var N = this.N, b = this.board, size = this.size;
    var near = new Uint8Array(N);
    var any = false;
    for (var i = 0; i < N; i++) {
      if (b[i]) {
        any = true;
        var x = i % size, y = (i / size) | 0;
        for (var dy = -radius; dy <= radius; dy++) {
          for (var dx = -radius; dx <= radius; dx++) {
            var nx = x + dx, ny = y + dy;
            if (nx >= 0 && nx < size && ny >= 0 && ny < size) near[ny * size + nx] = 1;
          }
        }
      }
    }
    var out = [];
    var open = openingPoints(size);
    if (!any) {
      var c = (size / 2) | 0;
      var lo = Math.max(0, c - 2), hi = Math.min(size - 1, c + 1);
      for (var yy = lo; yy <= hi; yy++) for (var xx = lo; xx <= hi; xx++) out.push(yy * size + xx);
      for (var o = 0; o < open.length; o++) if (out.indexOf(open[o]) < 0) out.push(open[o]);
      return out;
    }
    for (var j = 0; j < N; j++) if (near[j] && b[j] === EMPTY) out.push(j);
    // 空角 / 边上的大场：三、四线沿线的稀疏点，让 AI 不是只盯着局部
    var stones = 0;
    for (var s = 0; s < N; s++) if (b[s]) stones++;
    if (stones < N * 0.62) {
      for (var k = 0; k < N; k++) {
        if (b[k] || near[k]) continue;
        var kx = k % size, ky = (k / size) | 0;
        var line = Math.min(kx, ky, size - 1 - kx, size - 1 - ky);
        if (line < 2 || line > 4) continue;
        if ((kx + ky) % 3 !== 0) continue;
        out.push(k);
      }
      for (var q = 0; q < open.length; q++) {
        if (b[open[q]] === EMPTY && out.indexOf(open[q]) < 0) out.push(open[q]);
      }
    }
    return out;
  };

  // 合法候选（含试下回滚，排除自杀/劫/填眼）
  GoGame.prototype.legalCandidates = function (radius, color) {
    color = color || this.current;
    var list = this.candidates(radius);
    var out = [];
    for (var k = 0; k < list.length; k++) {
      var i = list[k];
      if (this.isEyeFill(i, color)) continue;
      var r = this.play(i);
      if (r.ok) { this.undo(); out.push(i); }
    }
    return out;
  };

  // 终局死子：按"是否有两个以上独立真眼区"粗略判断
  GoGame.prototype.autoMarkDead = function () {
    this.dead = new Set();
    var N = this.N, b = this.board;
    var seenGroup = new Uint8Array(N);
    var seenEmpty = new Uint8Array(N);

    for (var i = 0; i < N; i++) {
      if (b[i] === EMPTY || seenGroup[i]) continue;
      var color = b[i];
      var g = this.group(i);
      for (var s = 0; s < g.stones.length; s++) seenGroup[g.stones[s]] = 1;

      // 统计被本方完全包围的空区（近似眼位）
      var eyes = 0;
      var checked = new Int32Array(g.stones.length).fill(-1);
      for (var q = 0; q < g.stones.length; q++) {
        var ns = this.adj[g.stones[q]];
        for (var k = 0; k < ns.length; k++) {
          var e = ns[k];
          if (b[e] !== EMPTY || seenEmpty[e]) continue;
          // 洪泛该空区
          var stack = [e], region = [], borderOpp = false, borderEmptyOnly = true;
          seenEmpty[e] = 1;
          while (stack.length) {
            var p = stack.pop(); region.push(p);
            var pn = this.adj[p];
            for (var m = 0; m < pn.length; m++) {
              var u = pn[m];
              if (b[u] === EMPTY) { if (!seenEmpty[u]) { seenEmpty[u] = 1; stack.push(u); } }
              else if (b[u] !== color) borderOpp = true;
            }
          }
          if (!borderOpp && region.length > 0) eyes++;
        }
      }
      if (eyes < 2 && g.libs.length <= 2) {
        for (var t2 = 0; t2 < g.stones.length; t2++) this.dead.add(g.stones[t2]);
      }
    }
    return this.dead;
  };

  GoGame.prototype.toggleDead = function (i) {
    if (this.board[i] === EMPTY) return false;
    var g = this.group(i);
    var isDead = this.dead.has(i);
    for (var k = 0; k < g.stones.length; k++) {
      if (isDead) this.dead.delete(g.stones[k]);
      else this.dead.add(g.stones[k]);
    }
    this.result = null;
    return true;
  };

  GoGame.prototype.clearDead = function () { this.dead = new Set(); this.result = null; };

  // AI 用的快速形势判断：不做死子处理，只数子 + 空区归属
  GoGame.prototype.areaScore = function () {
    var N = this.N, b = this.board, adj = this.adj;
    var black = 0, white = 0;
    for (var i = 0; i < N; i++) {
      if (b[i] === BLACK) black++;
      else if (b[i] === WHITE) white++;
    }
    var seen = new Uint8Array(N);
    var blackTerr = 0, whiteTerr = 0, dame = 0;
    for (var s = 0; s < N; s++) {
      if (b[s] !== EMPTY || seen[s]) continue;
      var stack = [s], region = 0, tb = false, tw = false;
      seen[s] = 1;
      while (stack.length) {
        var p = stack.pop(); region++;
        var ns = adj[p];
        for (var k = 0; k < ns.length; k++) {
          var q = ns[k];
          if (b[q] === EMPTY) { if (!seen[q]) { seen[q] = 1; stack.push(q); } }
          else if (b[q] === BLACK) tb = true;
          else if (b[q] === WHITE) tw = true;
        }
      }
      if (tb && !tw) blackTerr += region;
      else if (tw && !tb) whiteTerr += region;
      else if (tb && tw) dame += region;
    }
    return {
      black: black + blackTerr + dame * 0.5,
      white: white + whiteTerr + dame * 0.5,
      line: N / 2 + this.komi,
      whiteLine: N / 2 - this.komi
    };
  };

  // 中国数子
  GoGame.prototype.score = function () {
    var N = this.N, b = Int8Array.from(this.board);
    var dead = this.dead;
    dead.forEach(function (i) { b[i] = EMPTY; });

    var blackStones = 0, whiteStones = 0;
    for (var i = 0; i < N; i++) {
      if (b[i] === BLACK) blackStones++;
      else if (b[i] === WHITE) whiteStones++;
    }

    var seen = new Uint8Array(N);
    var blackTerr = 0, whiteTerr = 0, dame = 0, neutral = 0;
    for (var s = 0; s < N; s++) {
      if (b[s] !== EMPTY || seen[s]) continue;
      var stack = [s], region = [], tb = false, tw = false;
      seen[s] = 1;
      while (stack.length) {
        var p = stack.pop(); region.push(p);
        var ns = this.adj[p];
        for (var k = 0; k < ns.length; k++) {
          var q = ns[k];
          if (b[q] === EMPTY) { if (!seen[q]) { seen[q] = 1; stack.push(q); } }
          else if (b[q] === BLACK) tb = true;
          else if (b[q] === WHITE) tw = true;
        }
      }
      if (tb && !tw) blackTerr += region.length;
      else if (tw && !tb) whiteTerr += region.length;
      else if (tb && tw) dame += region.length;
      else neutral += region.length;
    }

    var black = blackStones + blackTerr + dame * 0.5;
    var white = whiteStones + whiteTerr + dame * 0.5;
    var line = N / 2 + this.komi;      // 黑胜线：19 路 = 184.25
    var whiteLine = N - line;          // 白胜线：19 路 = 176.75

    var winner, diff;
    if (black > line) { winner = BLACK; diff = black - line; }
    else if (white > whiteLine) { winner = WHITE; diff = white - whiteLine; }
    else { winner = 0; diff = 0; }

    var res = {
      black: black, white: white,
      blackStones: blackStones, whiteStones: whiteStones,
      blackTerr: blackTerr, whiteTerr: whiteTerr, dame: dame, neutral: neutral,
      line: line, whiteLine: whiteLine,
      winner: winner, diff: diff,
      deadCount: dead.size
    };
    this.result = res;
    return res;
  };

  GoGame.prototype.clone = function () {
    var g = new GoGame(this.size, { komi: this.komi });
    g.board.set(this.board);
    g.current = this.current;
    g.koPoint = this.koPoint;
    g.consecutivePass = this.consecutivePass;
    g.gameOver = this.gameOver;
    g.scoringPhase = this.scoringPhase;
    g.dead = new Set(this.dead);
    g.captures = { 1: this.captures[1], 2: this.captures[2] };
    g.moveCount = this.moveCount;
    g.lastMove = this.lastMove;
    g._hash = this._hash;
    return g;
  };

  var api = { GoGame: GoGame, EMPTY: EMPTY, BLACK: BLACK, WHITE: WHITE, otherColor: otherColor };
  global.GoEngine = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
