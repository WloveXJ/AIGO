/*
 * app.js —— 界面与对局流程
 */
(function () {
  'use strict';

  var Engine = window.GoEngine;
  var GoAI = window.GoAI;
  var Analysis = window.GoAnalysis;
  var patternKey = window.GoMemoryLib.patternKey;
  var BLACK = 1, WHITE = 2;
  var LETTERS = 'ABCDEFGHJKLMNOPQRSTU';

  // 段位阶梯：18 级 → 1 级 → 初段 → 9 段。need = 在该阶段需要新增的训练局数。
  var RANKS = (function () {
    var list = [];
    for (var r = 18; r >= 1; r--) list.push({ name: r + ' 级', need: 8 });
    var seg = [20, 30, 40, 60, 80, 100, 120, 150, 200];
    for (var d = 1; d <= 9; d++) list.push({ name: d === 1 ? '初段' : d + ' 段', need: seg[d - 1] });
    return list;
  })();

  var $ = function (id) { return document.getElementById(id); };

  var els = {
    canvas: $('board'),
    turnText: $('turnText'), turnDot: document.querySelector('.turn .stone-dot'),
    boardMeta: $('boardMeta'), moveNo: $('moveNo'),
    thinking: $('thinking'),
    mask: $('resultMask'), resTitle: $('resultTitle'), resScore: $('resultScore'),
    resDetail: $('resultDetail'), btnAgain: $('btnAgain'),
    hint: $('hint'),
    capBlack: $('capBlack'), capWhite: $('capWhite'),
    aiLevel: $('aiLevel'),
    badgeGames: $('badgeGames'), badgeTrain: $('badgeTrain'),
    statGames: $('statGames'), statEntries: $('statEntries'),
    trainBar: $('trainBar'), trainLive: $('trainLive'), trainSpeed: $('trainSpeed'),
    chkTrain: $('chkTrain'), selTrainSize: $('selTrainSize'),
    selSize: $('selSize'), selColor: $('selColor'), selTime: $('selTime'),
    scoringBar: $('scoringBar'),
    btnNew: $('btnNew'), btnUndo: $('btnUndo'), btnPass: $('btnPass'),
    btnHint: $('btnHint'), btnResign: $('btnResign'), btnCount: $('btnCount'),
    btnAutoDead: $('btnAutoDead'), btnClearDead: $('btnClearDead'),
    btnConfirmScore: $('btnConfirmScore'), btnClearMem: $('btnClearMem'),
    // 形势判断
    evalTag: $('evalTag'), evalBlack: $('evalBlack'), evalWhite: $('evalWhite'),
    evalLead: $('evalLead'), evalWinrate: $('evalWinrate'), evalSub: $('evalSub'),
    winBar: $('winBar'), winBarBox: $('winBarBox'),
    chkTerritory: $('chkTerritory'), btnRefreshEval: $('btnRefreshEval'),
    trend: $('trend'),
    trendPrev: $('trendPrev'), trendNext: $('trendNext'), trendSlider: $('trendSlider'),
    trendPos: $('trendPos'), trendLive: $('trendLive'),
    // 段位
    rankBadge: $('rankBadge'), rankNext: $('rankNext'), rankGames: $('rankGames'),
    archCount: $('archCount'), archList: $('archList'),
    // 棋风
    selStyle: $('selStyle'), styleTag: $('styleTag'), studyStat: $('studyStat'),
    wuRows: $('wuRows'), dengRows: $('dengRows'), btnStudyAgain: $('btnStudyAgain'),
    // 数子申请
    countMask: $('countMask'), cBlack: $('cBlack'), cWhite: $('cWhite'),
    countRows: $('countRows'), countVerdict: $('countVerdict'), countNote: $('countNote'),
    btnCountCancel: $('btnCountCancel'), btnCountOk: $('btnCountOk'),
    countBar: $('countBar'), countBarText: $('countBarText'),
    btnCountAccept: $('btnCountAccept'), btnCountDecline: $('btnCountDecline')
  };

  var ctx = els.canvas.getContext('2d');
  var geom = { pad: 30, cell: 30, dim: 300, size: 19 };

  var state = {
    game: new Engine.GoGame(19, { komi: 3.75 }),
    playerColor: BLACK,
    mem: null,
    ai: null,
    thinking: false,
    moves: [],          // 用于学习 + 复盘：{i,color,no,patKey,h}
    suggestion: -1,
    hover: -1,
    recorded: false,
    worker: null,
    workerReady: false,
    trainSize: 19,
    speed: 0,
    // 分析
    eval: null,         // 当前形势判断结果
    trend: [],          // [{no, winrate, lead, kind}]
    trendHover: -1,
    showTerritory: false,
    aiRequested: false, // AI 本局是否已申请过数子
    // 复盘
    viewPly: 0,         // 当前看到第几手（含弃手）
    liveGame: null,     // 复盘时挂起的最新棋局
    // 段位
    stage: null,
    stageIndex: -1,
    stages: [],
    // 棋风
    styleMode: 'ai',
    styleName: 'AI 本体',
    studyRound: 0
  };

  /* ---------------- 尺寸与绘制 ---------------- */

  function layout() {
    var wrap = els.canvas.parentElement;
    var size = state.game.size;
    var availW = wrap.clientWidth || 600;

    // 分析面板现在在棋盘右侧/下方，棋盘高度只受窗口高度限制
    var topbar = document.querySelector('.topbar');
    var topH = topbar ? topbar.getBoundingClientRect().height + 16 : 84;
    var chromeH = 168;               // 棋盘卡片里除棋盘以外的高度
    var availH = window.innerHeight - 54 - topH - chromeH;

    var dim = Math.floor(Math.min(availW, Math.max(320, availH), size >= 19 ? 900 : 9999));
    var dpr = window.devicePixelRatio || 1;

    els.canvas.style.width = dim + 'px';
    els.canvas.style.height = dim + 'px';
    els.canvas.style.margin = '0 auto';
    els.canvas.width = Math.round(dim * dpr);
    els.canvas.height = Math.round(dim * dpr);
  }

  // 按画布实际显示尺寸换算几何，保证绘制与显示一致
  function computeGeom() {
    var size = state.game.size;
    var cw = els.canvas.clientWidth || parseFloat(els.canvas.style.width) || 600;
    var pad = Math.max(18, Math.round(cw * 0.043));
    var cell = (cw - pad * 2) / (size - 1);
    return { pad: pad, cell: cell, dim: cw, size: size };
  }

  function drawStone(cx, cy, color, radius) {
    var r = radius || geom.cell * 0.465;
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx + r * 0.06, cy + r * 0.14, r * 0.98, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(74, 48, 14, .22)';
    ctx.fill();

    var grad = ctx.createRadialGradient(cx - r * 0.36, cy - r * 0.42, r * 0.08, cx, cy, r * 1.06);
    if (color === BLACK) {
      grad.addColorStop(0, '#616161');
      grad.addColorStop(0.4, '#2a2a2a');
      grad.addColorStop(1, '#080808');
    } else {
      grad.addColorStop(0, '#ffffff');
      grad.addColorStop(0.6, '#f5f4f0');
      grad.addColorStop(1, '#cfcdc6');
    }
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    if (color === WHITE) {
      ctx.strokeStyle = 'rgba(120,115,105,.35)';
      ctx.lineWidth = 0.8;
      ctx.stroke();
    }
    ctx.restore();
  }

  function draw() {
    var g = state.game;
    var dpr = window.devicePixelRatio || 1;
    var cw = els.canvas.clientWidth || parseFloat(els.canvas.style.width) || 600;
    if (Math.abs(els.canvas.width - Math.round(cw * dpr)) > 1) {
      els.canvas.width = Math.round(cw * dpr);
      els.canvas.height = Math.round(cw * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    geom = computeGeom();

    var size = g.size, cell = geom.cell, pad = geom.pad, dim = geom.dim;

    ctx.clearRect(0, 0, dim, dim);

    var grad = ctx.createLinearGradient(0, 0, dim, dim);
    grad.addColorStop(0, '#f2dcb2');
    grad.addColorStop(0.5, '#eacd9c');
    grad.addColorStop(1, '#dfb87e');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, dim, dim);

    // 木纹
    ctx.save();
    ctx.globalAlpha = 0.06;
    ctx.strokeStyle = '#7a4f18';
    for (var w = 0; w < 26; w++) {
      var yy = (w + 0.5) * dim / 26;
      ctx.beginPath();
      ctx.moveTo(0, yy);
      ctx.bezierCurveTo(dim * 0.3, yy + 6, dim * 0.65, yy - 7, dim, yy + 3);
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.restore();

    // 网格
    var end = pad + cell * (size - 1);
    ctx.strokeStyle = 'rgba(88, 58, 22, .55)';
    ctx.lineWidth = 1;
    for (var i = 0; i < size; i++) {
      var p = Math.round(pad + i * cell) + 0.5;
      ctx.beginPath(); ctx.moveTo(p, pad); ctx.lineTo(p, end); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(pad, p); ctx.lineTo(end, p); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(70, 45, 15, .75)';
    ctx.lineWidth = 1.6;
    ctx.strokeRect(pad - 0.5, pad - 0.5, end - pad + 1, end - pad + 1);

    // 星位
    var stars = size === 19 ? [3, 9, 15] : size === 13 ? [3, 6, 9] : [2, 4, 6];
    ctx.fillStyle = 'rgba(70, 45, 15, .8)';
    for (var sx = 0; sx < stars.length; sx++) {
      for (var sy = 0; sy < stars.length; sy++) {
        ctx.beginPath();
        ctx.arc(pad + stars[sx] * cell, pad + stars[sy] * cell, Math.max(2, cell * 0.075), 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 坐标
    ctx.fillStyle = 'rgba(90, 62, 26, .6)';
    ctx.font = Math.max(9, Math.round(cell * 0.34)) + 'px -apple-system, "Segoe UI", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (var c = 0; c < size; c++) {
      var cx = pad + c * cell;
      ctx.fillText(LETTERS[c], cx, dim - pad * 0.42);
      ctx.fillText(String(size - c), pad * 0.42, pad + c * cell);
    }

    // 形势叠加：领地归属（黑方黑方块、白方白方块，逐点标记）
    if (state.showTerritory && state.eval) {
      var terr = state.eval.territory;
      var hs = Math.max(2.5, cell * 0.175);
      for (var t = 0; t < g.N; t++) {
        if (!terr[t] || g.board[t]) continue;
        var tx = pad + (t % size) * cell, ty = pad + ((t / size) | 0) * cell;
        if (terr[t] === BLACK) {
          ctx.fillStyle = 'rgba(20,20,20,.92)';
          ctx.fillRect(tx - hs, ty - hs, hs * 2, hs * 2);
        } else {
          ctx.fillStyle = 'rgba(255,255,255,.96)';
          ctx.fillRect(tx - hs, ty - hs, hs * 2, hs * 2);
          ctx.strokeStyle = 'rgba(96,84,66,.55)';
          ctx.lineWidth = 1;
          ctx.strokeRect(tx - hs + 0.5, ty - hs + 0.5, hs * 2 - 1, hs * 2 - 1);
        }
      }
    }

    // 棋子
    for (var k = 0; k < g.N; k++) {
      var v = g.board[k];
      if (!v) continue;
      var x = k % size, y = (k / size) | 0;
      var px = pad + x * cell, py = pad + y * cell;
      drawStone(px, py, v);

      if (g.dead.has(k)) {
        ctx.save();
        ctx.strokeStyle = v === BLACK ? 'rgba(255,255,255,.85)' : 'rgba(200,40,40,.85)';
        ctx.lineWidth = Math.max(1.5, cell * 0.06);
        var d = cell * 0.2;
        ctx.beginPath();
        ctx.moveTo(px - d, py - d); ctx.lineTo(px + d, py + d);
        ctx.moveTo(px + d, py - d); ctx.lineTo(px - d, py + d);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 形势叠加：弱棋提醒（气=1 红圈，气=2 橙圈）
    if (state.showTerritory && state.eval) {
      var danger = state.eval.danger;
      for (var q = 0; q < g.N; q++) {
        var lv = danger[q];
        if (!lv || !g.board[q]) continue;
        var qx = pad + (q % size) * cell, qy = pad + ((q / size) | 0) * cell;
        ctx.beginPath();
        ctx.arc(qx, qy, cell * 0.47, 0, Math.PI * 2);
        ctx.strokeStyle = lv === 2 ? 'rgba(180,35,24,.92)' : 'rgba(214,132,26,.85)';
        ctx.lineWidth = Math.max(1.6, cell * 0.06);
        ctx.stroke();
      }
    }

    // 最后一手
    if (g.lastMove >= 0 && g.board[g.lastMove]) {
      var lx = pad + (g.lastMove % size) * cell;
      var ly = pad + ((g.lastMove / size) | 0) * cell;
      ctx.beginPath();
      ctx.arc(lx, ly, Math.max(2, cell * 0.13), 0, Math.PI * 2);
      ctx.fillStyle = g.board[g.lastMove] === BLACK ? '#f2efe8' : '#1c1c1c';
      ctx.fill();
    }

    // 建议点
    if (state.suggestion >= 0) {
      var gx = pad + (state.suggestion % size) * cell;
      var gy = pad + ((state.suggestion / size) | 0) * cell;
      ctx.beginPath();
      ctx.arc(gx, gy, cell * 0.42, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(15,118,110,.9)';
      ctx.lineWidth = Math.max(2, cell * 0.075);
      ctx.stroke();
    }

    // 悬停虚影（复盘时不允许落子，不画）
    if (state.hover >= 0 && !g.board[state.hover] && !g.gameOver && !state.liveGame) {
      var hx = pad + (state.hover % size) * cell;
      var hy = pad + ((state.hover / size) | 0) * cell;
      ctx.save();
      ctx.globalAlpha = 0.38;
      drawStone(hx, hy, g.current);
      ctx.restore();
    }
  }

  /* ---------------- 棋风：吴棋 / 邓棋 ----------------
   * 棋谱里的黑方按「吴棋」建模、白方按「邓棋」建模。
   * 镜像模式 = AI 用这个人的棋风画像 + 录像开局手册来下。
   */

  var STYLES = null;

  function buildStyles() {
    var S = window.GoStudy;
    if (!S || STYLES) return;
    var wuProfile = S.buildProfile(S.GAMES, BLACK);
    var dengProfile = S.buildProfile(S.GAMES, WHITE);
    STYLES = {
      wu: {
        name: '吴棋',
        color: BLACK,
        profile: wuProfile,
        book: S.buildBook(Engine, S.GAMES, BLACK),
        strength: 1.15
      },
      deng: {
        name: '邓棋',
        color: WHITE,
        profile: dengProfile,
        book: S.buildBook(Engine, S.GAMES, WHITE),
        strength: 1.15
      }
    };
    renderStyleCards();
  }

  function pct(v) { return Math.round(v * 100) + '%'; }

  function linePeak(profile) {
    // 3=四线, 2=三线, 1=二线；取权重最高的那一档
    var best = 2, bestV = -1;
    for (var k = 1; k <= 3; k++) {
      if (profile.line[k] > bestV) { bestV = profile.line[k]; best = k; }
    }
    return (best + 1) + ' 线';
  }

  function styleRows(profile) {
    var sum = profile.region[0] + profile.region[1] + profile.region[2] || 1;
    return [
      ['常用', linePeak(profile)],
      ['开局占角', pct(profile.openerCorner)],
      ['平均手距', profile.avgDist.toFixed(1) + ' 路'],
      ['角/边/中', Math.round(profile.region[0] / sum * 100) + '/' +
        Math.round(profile.region[1] / sum * 100) + '/' + Math.round(profile.region[2] / sum * 100)],
      ['手数样本', profile.moves + ' 手']
    ];
  }

  function renderStyleCards() {
    if (!STYLES || !els.wuRows) return;
    var html = function (rows) {
      return rows.map(function (r) {
        return '<div class="sc-row"><span>' + r[0] + '</span><b>' + r[1] + '</b></div>';
      }).join('');
    };
    els.wuRows.innerHTML = html(styleRows(STYLES.wu.profile));
    els.dengRows.innerHTML = html(styleRows(STYLES.deng.profile));
  }

  function aiColorNow() {
    return state.playerColor === BLACK ? WHITE : BLACK;
  }

  // 依据模式给 AI 套棋风
  function applyStyle(silent) {
    if (!state.ai) return;
    buildStyles();
    var mode = els.selStyle ? els.selStyle.value : 'ai';
    var pick = null;
    if (mode === 'wu') pick = STYLES && STYLES.wu;
    else if (mode === 'deng') pick = STYLES && STYLES.deng;
    else if (mode === 'mirror') {
      pick = aiColorNow() === BLACK ? (STYLES && STYLES.wu) : (STYLES && STYLES.deng);
    }
    if (pick) {
      state.ai.setStyle({ name: pick.name, profile: pick.profile, book: pick.book, strength: pick.strength });
    } else {
      state.ai.setStyle(null);
    }
    state.styleMode = mode;
    state.styleName = pick ? pick.name : 'AI 本体';

    if (els.styleTag) els.styleTag.textContent = pick ? pick.name + '镜像' : 'AI 本体';
    var cards = document.querySelectorAll('.style-card');
    if (cards.length === 2) {
      cards[0].classList.toggle('active', !!pick && pick.name === '吴棋');
      cards[1].classList.toggle('active', !!pick && pick.name === '邓棋');
    }
    if (!silent) {
      if (!pick) setHint('AI 回到本体棋风：只靠棋型记忆与搜索。');
      else {
        setHint(pick.name + '镜像已生效：开局照录像走，之后按' + pick.name +
          '的习惯选点（' + linePeak(pick.profile) + '为主，平均手距 ' +
          pick.profile.avgDist.toFixed(1) + ' 路）。');
      }
    }
  }

  /* ---------------- 状态文本 ---------------- */

  function updateStatus() {
    var g = state.game;
    var isPlayer = g.current === state.playerColor;
    var total = state.moves.length;

    if (state.liveGame) {
      els.turnText.textContent = '复盘 · 第 ' + state.viewPly + ' / ' + total + ' 手';
    } else {
      els.turnText.textContent = g.gameOver
        ? (g.scoringPhase ? '结算阶段' : '对局结束')
        : (isPlayer ? '轮到你（' + (g.current === BLACK ? '黑' : '白') + '）'
          : 'AI 落子（' + (g.current === BLACK ? '黑' : '白') + '）');
    }

    els.turnDot.className = 'stone-dot' + (g.current === WHITE ? ' white' : '');
    els.boardMeta.textContent = g.size + ' 路 · 贴 3.75 子';
    els.moveNo.textContent = state.liveGame
      ? '第 ' + state.viewPly + ' / ' + total + ' 手'
      : '第 ' + g.moveCount + ' 手';
    els.capBlack.textContent = g.captures[BLACK];
    els.capWhite.textContent = g.captures[WHITE];

    var st = state.mem ? state.mem.stats() : { games: 0, humanGames: 0, entries: 0 };
    els.statGames.textContent = st.games + (st.humanGames ? ' + ' + st.humanGames : '');
    els.statEntries.textContent = st.entries;
    els.badgeGames.textContent = '训练 ' + (st.games + (st.humanGames || 0)) + ' 局';
    if (els.studyStat) {
      var passes = st.studyPasses || 0;
      els.studyStat.textContent = passes + ' 遍 · ' +
        Math.round(st.studyMoves || 0) + ' 手';
    }
    updateStage(st);
  }

  function stageInfo(games) {
    var acc = 0;
    var last = RANKS.length - 1;
    for (var i = 0; i < RANKS.length; i++) {
      var need = RANKS[i].need;
      if (games < acc + need) {
        return {
          index: i, name: RANKS[i].name, base: acc, need: need,
          done: Math.max(0, games - acc), max: false
        };
      }
      acc += need;
    }
    return {
      index: last, name: RANKS[last].name,
      base: acc - RANKS[last].need, need: RANKS[last].need,
      done: RANKS[last].need, max: true
    };
  }

  function updateStage(st) {
    var total = (st.games || 0) + (st.humanGames || 0);
    var info = stageInfo(total);
    state.stage = info;

    els.rankBadge.textContent = info.name;
    els.rankGames.textContent = '累计 ' + total + ' 局';
    els.rankNext.textContent = info.max
      ? '已达最高段位'
      : '距 ' + RANKS[info.index + 1].name + ' 还需 ' + Math.max(0, info.need - info.done) + ' 局';
    els.trainBar.style.width = Math.min(100, (info.done / info.need) * 100) + '%';
    els.aiLevel.textContent = info.name;

    if (state.stageIndex < 0) { state.stageIndex = info.index; return; }
    if (info.index > state.stageIndex) {
      archiveStage(state.stageIndex, info);
      state.stageIndex = info.index;
    }
  }

  // 升段时把上一阶段的记忆冻结存档
  function archiveStage(oldIndex, info) {
    if (oldIndex < 0 || oldIndex >= RANKS.length || !state.mem) return;
    var name = RANKS[oldIndex].name;
    var st = state.mem ? state.mem.stats() : { patterns: 0, book: 0 };
    var rec = {
      key: 'stage-' + oldIndex + '-' + Date.now(),
      index: oldIndex,
      name: name,
      games: info.base,
      patterns: st.patterns,
      book: st.book,
      ts: Date.now()
    };
    state.mem.saveStage(rec).then(function () {
      loadStages();
      setHint('AI 晋升到「' + info.name + '」，上一阶段「' + name + '」的记忆已存档。');
    });
  }

  function loadStages() {
    if (!state.mem) return;
    state.mem.listStages().then(function (list) {
      state.stages = list || [];
      els.archCount.textContent = state.stages.length ? '· ' + state.stages.length + ' 份' : '';
      if (!state.stages.length) {
        els.archList.innerHTML = '<span class="arch-empty">升段时自动保存上一阶段</span>';
        return;
      }
      var html = state.stages.slice(-8).reverse().map(function (s) {
        var d = new Date(s.ts);
        var tip = d.toLocaleString('zh-CN') + ' · ' + s.games + ' 局 · ' +
          s.patterns + ' 棋型 / ' + s.book + ' 开局';
        return '<span class="arch-chip" title="' + tip + '">' + s.name +
          '<em>' + s.games + ' 局</em></span>';
      }).join('');
      els.archList.innerHTML = html;
    });
  }

  function setHint(text) { els.hint.textContent = text; }

  /* ---------------- 形势判断 ---------------- */

  function evaluateNow() {
    var g = state.game;
    var opts = (g.scoringPhase && g.dead && g.dead.size) ? { dead: g.dead } : null;
    try { state.eval = Analysis.estimate(g, opts); }
    catch (err) { state.eval = null; }

    // 结算阶段以正式数子结果为准，避免与"确认结算"的数字不一致
    var ev = state.eval;
    if (ev && g.scoringPhase) {
      var s = g.score();
      ev.black = s.black; ev.white = s.white;
      ev.blackStones = s.blackStones; ev.whiteStones = s.whiteStones;
      ev.blackTerr = s.blackTerr; ev.whiteTerr = s.whiteTerr;
      ev.dame = s.dame; ev.deadCount = s.deadCount;
      ev.line = s.line; ev.whiteLine = s.whiteLine;
      ev.winner = s.winner; ev.diff = s.diff;
      ev.lead = s.winner === BLACK ? s.diff : (s.winner === WHITE ? -s.diff
        : (s.black >= s.white ? s.black - s.line : -(s.white - s.whiteLine)));
      ev.blackWinrate = Analysis.winrateOf(s.black - s.line, g.N);
    }
    return ev;
  }

  // 每落一手记一个点：X 用棋谱步数（含弃手），悔棋时可精确回退
  function pushTrend(kind) {
    var g = state.game;
    var ev = evaluateNow();
    if (!ev) return;
    var t = state.trend;
    var no = g._stack.length;
    while (t.length && t[t.length - 1].no >= no) t.pop();
    t.push({ no: no, winrate: ev.blackWinrate, lead: ev.lead, kind: kind || 'move' });
    while (t.length > 600) t.shift();
  }

  function syncTrend() {
    var g = state.game;
    var no = g._stack.length;
    var t = state.trend;
    while (t.length && t[t.length - 1].no > no) t.pop();
    if (!t.length) {
      var ev = evaluateNow();
      t.push({ no: 0, winrate: ev ? ev.blackWinrate : 0.5, lead: 0, kind: 'start' });
    }
  }

  function resetTrend() {
    state.trend = [];
    var ev = evaluateNow();
    state.trend.push({ no: 0, winrate: ev ? ev.blackWinrate : 0.5, lead: ev ? ev.lead : 0, kind: 'start' });
    state.trendHover = -1;
  }

  function updateEvalUI() {
    var ev = state.eval;
    if (!ev) {
      els.evalBlack.textContent = '—';
      els.evalWhite.textContent = '—';
      return;
    }
    els.evalBlack.textContent = ev.black.toFixed(1);
    els.evalWhite.textContent = ev.white.toFixed(1);
    els.evalLead.textContent = Analysis.leadText(ev);
    els.evalWinrate.textContent = '黑胜率 ' + (ev.blackWinrate * 100).toFixed(1) + '%';
    els.winBar.style.width = (ev.blackWinrate * 100).toFixed(1) + '%';
    els.evalTag.textContent = state.game.scoringPhase ? '结算数子' : '本地估算';

    var bits = [];
    bits.push('黑 ' + ev.blackStones + ' 子 + 空 ' + ev.blackTerr);
    bits.push('白 ' + ev.whiteStones + ' 子 + 空 ' + ev.whiteTerr);
    bits.push('未定 ' + ev.dame + ' 点各半');
    if (ev.deadCount) bits.push('死子 ' + ev.deadCount);
    if (ev.weak.length) bits.push('弱棋 ' + ev.weak.length + ' 块');
    bits.push('黑胜线 ' + ev.line.toFixed(2));
    els.evalSub.textContent = bits.join(' · ');
  }

  /* ---------------- 胜率走势图（双轴：胜率 / 目差） ---------------- */

  var trendGeom = null;

  function fmtLead(v) {
    var r = Math.round(v * 10) / 10;
    return (r % 1 === 0) ? String(r) : r.toFixed(1);
  }

  function trendAtPly(no) {
    var t = state.trend;
    if (!t.length) return null;
    var best = t[0];
    for (var i = 0; i < t.length; i++) {
      if (t[i].no <= no) best = t[i]; else break;
    }
    return best;
  }

  function syncTrendFoot() {
    if (!els.trendSlider) return;
    var total = state.moves.length;
    els.trendSlider.max = String(total);
    els.trendSlider.value = String(Math.min(state.viewPly, total));
    els.trendPos.textContent = state.viewPly + ' / ' + total;
    els.trendLive.hidden = !state.liveGame;
    els.trendPrev.disabled = state.viewPly <= 0;
    els.trendNext.disabled = state.viewPly >= total;
  }

  function drawTrend() {
    var c = els.trend;
    if (!c) return;
    var dpr = window.devicePixelRatio || 1;
    var cssW = c.clientWidth || (c.parentElement ? c.parentElement.clientWidth : 520) || 520;
    var cssH = c.clientHeight || 148;
    if (c.width !== Math.round(cssW * dpr) || c.height !== Math.round(cssH * dpr)) {
      c.width = Math.round(cssW * dpr);
      c.height = Math.round(cssH * dpr);
    }
    var g2 = c.getContext('2d');
    g2.setTransform(dpr, 0, 0, dpr, 0, 0);
    g2.clearRect(0, 0, cssW, cssH);

    var padL = 30, padR = 34, padT = 24, padB = 12;
    var w = Math.max(30, cssW - padL - padR);
    var h = Math.max(30, cssH - padT - padB);

    var data = state.trend.length ? state.trend : [{ no: 0, winrate: 0.5, lead: 0, kind: 'start' }];
    var maxNo = Math.max(10, data[data.length - 1].no);

    // 目差轴范围：至少 ±10 目，随局面自动放宽
    var maxAbs = 10;
    for (var i = 0; i < data.length; i++) {
      var av = Math.abs(data[i].lead || 0) * 2;
      if (av > maxAbs) maxAbs = av;
    }
    var R = Math.min(40, Math.ceil(maxAbs / 5) * 5);

    var xs = function (no) { return padL + (no / maxNo) * w; };
    var yRate = function (v) { return padT + (1 - v) * h; };
    var yLead = function (p) {
      var q = Math.max(-R, Math.min(R, p));
      return padT + (1 - (q + R) / (2 * R)) * h;
    };

    g2.fillStyle = '#fffdf8';
    g2.fillRect(padL, padT, w, h);

    g2.font = '10px "Segoe UI", "Microsoft YaHei", sans-serif';
    g2.textBaseline = 'middle';

    // 横向网格 + 左右双轴（左：胜率，右：目差）
    var rows = [
      { v: 1, label: '100', lead: R },
      { v: 0.75, label: '75', lead: R / 2 },
      { v: 0.5, label: '50', lead: 0 },
      { v: 0.25, label: '25', lead: -R / 2 },
      { v: 0, label: '0', lead: -R }
    ];
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      var y = Math.round(yRate(row.v)) + 0.5;
      g2.beginPath();
      g2.moveTo(padL, y); g2.lineTo(padL + w, y);
      g2.strokeStyle = row.v === 0.5 ? '#d8d0be' : '#f1ece1';
      g2.lineWidth = 1;
      g2.stroke();

      g2.fillStyle = '#a9a08e';
      g2.textAlign = 'right';
      g2.fillText(row.label, padL - 6, y);
      g2.textAlign = 'left';
      g2.fillText((row.lead > 0 ? '+' : '') + fmtLead(row.lead), padL + w + 6, y);
    }

    // 竖向网格
    for (var d = 1; d < 4; d++) {
      var vx = Math.round(padL + (w / 4) * d) + 0.5;
      g2.beginPath();
      g2.moveTo(vx, padT); g2.lineTo(vx, padT + h);
      g2.strokeStyle = '#f4f0e7';
      g2.lineWidth = 1;
      g2.stroke();
    }

    g2.strokeStyle = '#e4ddcd';
    g2.lineWidth = 1;
    g2.strokeRect(padL + 0.5, padT + 0.5, w - 1, h - 1);

    var pts = data.map(function (dd) {
      return {
        x: xs(dd.no),
        y: yRate(dd.winrate),
        ly: yLead((dd.lead || 0) * 2),
        d: dd
      };
    });

    // 目差曲线（橙黄，右轴）
    if (pts.length > 1) {
      g2.beginPath();
      g2.moveTo(pts[0].x, pts[0].ly);
      for (var j = 1; j < pts.length; j++) g2.lineTo(pts[j].x, pts[j].ly);
      g2.strokeStyle = '#f0a300';
      g2.lineWidth = 1.4;
      g2.lineJoin = 'round';
      g2.stroke();
    }

    // 黑方胜率曲线（红，左轴）
    if (pts.length > 1) {
      g2.beginPath();
      g2.moveTo(pts[0].x, pts[0].y);
      for (var k = 1; k < pts.length; k++) g2.lineTo(pts[k].x, pts[k].y);
      g2.strokeStyle = '#e0211f';
      g2.lineWidth = 1.7;
      g2.lineJoin = 'round';
      g2.stroke();
    }

    // 当前查看位置
    var curNo = Math.min(state.viewPly, maxNo);
    var cur = trendAtPly(curNo);
    if (cur) {
      var cx = xs(curNo);
      g2.save();
      g2.setLineDash([2, 3]);
      g2.beginPath();
      g2.moveTo(Math.round(cx) + 0.5, padT + 1);
      g2.lineTo(Math.round(cx) + 0.5, padT + h - 1);
      g2.strokeStyle = 'rgba(79,111,208,.55)';
      g2.lineWidth = 1;
      g2.stroke();
      g2.restore();

      g2.beginPath();
      g2.arc(cx, yRate(cur.winrate), 3.4, 0, Math.PI * 2);
      g2.fillStyle = '#4f6fd0';
      g2.fill();
      g2.strokeStyle = 'rgba(255,255,255,.9)';
      g2.lineWidth = 1;
      g2.stroke();
    }

    // 悬停：竖线 + 两个点 + 顶部黄框
    if (state.trendHover >= 0 && state.trendHover < pts.length) {
      var hp = pts[state.trendHover];
      g2.beginPath();
      g2.moveTo(Math.round(hp.x) + 0.5, padT);
      g2.lineTo(Math.round(hp.x) + 0.5, padT + h);
      g2.strokeStyle = 'rgba(110,104,92,.45)';
      g2.lineWidth = 1;
      g2.stroke();

      g2.beginPath();
      g2.arc(hp.x, hp.ly, 2.8, 0, Math.PI * 2);
      g2.fillStyle = '#f0a300';
      g2.fill();
      g2.beginPath();
      g2.arc(hp.x, hp.y, 3.2, 0, Math.PI * 2);
      g2.fillStyle = '#e0211f';
      g2.fill();

      var dp = (hp.d.lead || 0) * 2;
      var txt = hp.d.no + ' 手  ' + (hp.d.winrate * 100).toFixed(1) + '%（' +
        (dp > 0 ? '+' : '') + fmtLead(dp) + ' 目）';
      g2.font = '10.5px "Segoe UI", "Microsoft YaHei", sans-serif';
      var tw = g2.measureText(txt).width + 16;
      var bx = Math.min(Math.max(padL, hp.x - tw / 2), padL + w - tw);
      var by = 3;
      g2.beginPath();
      if (g2.roundRect) g2.roundRect(bx, by, tw, 17, 4);
      else g2.rect(bx, by, tw, 17);
      g2.fillStyle = '#fdf4c8';
      g2.fill();
      g2.strokeStyle = '#e3cd7a';
      g2.lineWidth = 1;
      g2.stroke();
      g2.fillStyle = '#6b5410';
      g2.textAlign = 'center';
      g2.textBaseline = 'middle';
      g2.fillText(txt, bx + tw / 2, by + 8.5);
    }

    trendGeom = {
      padL: padL, padR: padR, padT: padT, w: w, h: h,
      maxNo: maxNo, pts: pts, cssW: cssW
    };
  }

  function trendHoverAt(clientX) {
    if (!trendGeom || !trendGeom.pts.length) return -1;
    var rect = els.trend.getBoundingClientRect();
    var x = clientX - rect.left;
    var no = ((x - trendGeom.padL) / trendGeom.w) * trendGeom.maxNo;
    var best = -1, bestD = 1e9;
    for (var i = 0; i < trendGeom.pts.length; i++) {
      var d = Math.abs(trendGeom.pts[i].d.no - no);
      if (d < bestD) { bestD = d; best = i; }
    }
    return best;
  }

  function render() {
    evaluateNow();
    layout();
    draw();
    updateStatus();
    updateEvalUI();
    drawTrend();
    syncTrendFoot();
  }

  /* ---------------- 复盘（走势图定位） ---------------- */

  // 从棋谱重建第 n 手局面，用于回看；最新棋局挂在 state.liveGame 里不丢
  function buildView(n) {
    var size = state.liveGame ? state.liveGame.size : state.game.size;
    var g = new Engine.GoGame(size, { komi: 3.75 });
    for (var k = 0; k < n; k++) {
      var m = state.moves[k];
      if (!m || m.i < 0) { g.pass(); continue; }
      var r = g.play(m.i);
      if (!r.ok) g.pass();
    }
    if (g.gameOver) g.autoMarkDead();

    state.game = g;
    state.viewPly = n;
    state.suggestion = -1;
    state.hover = -1;
    state.trendHover = -1;
    els.mask.hidden = true;
    els.scoringBar.hidden = true;
    els.countBar.hidden = true;
    render();
  }

  function gotoPly(n) {
    var total = state.moves.length;
    n = Math.max(0, Math.min(total, n | 0));
    if (state.thinking) { syncTrendFoot(); setHint('AI 思考中，稍后再拖动走势。'); return; }
    if (n === total) { backToLive(); return; }
    if (!state.liveGame) {
      state.liveGame = state.game;
      state.viewPly = total;
    }
    buildView(n);
    setHint('复盘中：第 ' + n + ' / ' + total + ' 手，拖动滑杆或点走势图可跳转。');
  }

  function backToLive() {
    if (!state.liveGame) {
      state.viewPly = state.moves.length;
      syncTrendFoot();
      return;
    }
    state.game = state.liveGame;
    state.liveGame = null;
    state.viewPly = state.moves.length;
    state.trendHover = -1;
    render();
    setHint('已回到最新局面。');
  }

  /* ---------------- 落子流程 ---------------- */

  function coordName(i) {
    var size = state.game.size;
    return LETTERS[i % size] + (size - ((i / size) | 0));
  }

  function recordMove(i, color) {
    state.moves.push({
      i: i, color: color, no: state.game.moveCount + 1,
      patKey: i >= 0 ? patternKey(state.game, i, color) : -1,
      h: state.game.hash()
    });
  }

  function playHuman(i) {
    if (state.liveGame) backToLive();
    var g = state.game;
    if (g.gameOver) {
      if (g.scoringPhase) { g.toggleDead(i); render(); }
      return;
    }
    if (state.thinking || g.current !== state.playerColor) return;

    recordMove(i, g.current);
    var r = g.play(i);
    if (!r.ok) {
      state.moves.pop();
      var map = { occupied: '该点已有棋子', ko: '打劫禁着点，需先在别处落一手', suicide: '禁着点（自杀）', outside: '超出棋盘' };
      setHint(map[r.reason] || '该点不可落子');
      return;
    }

    state.suggestion = -1;
    state.viewPly = state.moves.length;
    pushTrend('move');
    render();
    if (g.gameOver) { enterScoring(); return; }
    aiTurn();
  }

  function aiTurn() {
    var g = state.game;
    if (g.gameOver) return;
    state.thinking = true;
    els.thinking.hidden = false;

    requestAnimationFrame(function () {
      setTimeout(function () {
        var res = state.ai.chooseMove(g, { timeMs: parseInt(els.selTime.value, 10) });
        var mv = res.move;
        var passed = false;
        if (mv === -1 || g.current === state.playerColor) {
          // 没有可下的点 / 异常：直接弃权
          if (g.current !== state.playerColor) {
            recordMove(-1, g.current);
            g.pass();
            passed = true;
          }
        } else {
          recordMove(mv, g.current);
          var r = g.play(mv);
          if (!r.ok) { recordMove(-1, g.current); g.pass(); passed = true; }
        }

        state.thinking = false;
        els.thinking.hidden = true;
        state.viewPly = state.moves.length;
        pushTrend(passed ? 'pass' : 'move');
        render();

        if (g.gameOver) enterScoring();
        else {
          setHint('AI 用时 ' + res.elapsed + 'ms，思考 ' + res.iterations + ' 个分支。' +
            (res.winrate ? 'AI 自评胜率 ' + (res.winrate * 100).toFixed(0) + '%。' : ''));
          maybeAiRequest();
        }
      }, 40);
    });
  }

  // AI 大优/大劣且局面已展开时，会主动申请数子（每局最多一次）
  function maybeAiRequest() {
    var g = state.game;
    if (g.gameOver || state.aiRequested || !state.eval) return;
    if (g.moveCount < Math.max(24, g.size * 2)) return;
    var aiColor = state.playerColor === BLACK ? WHITE : BLACK;
    var aiRate = aiColor === BLACK ? state.eval.blackWinrate : 1 - state.eval.blackWinrate;
    if (aiRate < 0.965) return;
    state.aiRequested = true;
    els.countBarText.textContent = 'AI 判断形势已定（自评胜率 ' + (aiRate * 100).toFixed(0) + '%），申请数子。';
    els.countBar.hidden = false;
  }

  /* ---------------- 结算 ---------------- */

  function enterScoring() {
    var g = state.game;
    g.autoMarkDead();
    els.countMask.hidden = true;
    els.countBar.hidden = true;
    pushTrend('request');
    render();
    els.scoringBar.hidden = false;
    setHint('进入结算阶段。已自动标记死子，可点击棋块修正后确认。');
    showScorePreview();
  }

  function showScorePreview() {
    var s = state.game.score();
    els.scoringBar.hidden = false;
    setHint('预估：黑 ' + s.black.toFixed(1) + ' 子 / 白 ' + s.white.toFixed(1) + ' 子（黑胜线 ' +
      s.line.toFixed(2) + '，白胜线 ' + s.whiteLine.toFixed(2) + '）');
  }

  function resultText(s) {
    if (!s.winner) return '和棋';
    var name = s.winner === BLACK ? '黑棋' : '白棋';
    return name + '胜 ' + s.diff.toFixed(2) + ' 子';
  }

  function showResult(title, scoreLine, detail) {
    els.resTitle.textContent = title;
    els.resScore.innerHTML = scoreLine;
    els.resDetail.innerHTML = detail;
    els.btnAgain.textContent = '再来一局';
    els.mask.hidden = false;
  }

  function confirmScoring() {
    var g = state.game;
    var s = g.score();
    els.scoringBar.hidden = true;
    els.countBar.hidden = true;

    showResult(resultText(s),
      '黑 <b>' + s.black.toFixed(1) + '</b> 子 &nbsp;/&nbsp; 白 <b>' + s.white.toFixed(1) + '</b> 子',
      '黑胜线 ' + s.line.toFixed(2) + ' · 白胜线 ' + s.whiteLine.toFixed(2) + '<br>' +
      '黑：活子 ' + s.blackStones + ' + 空 ' + s.blackTerr.toFixed(1) + '<br>' +
      '白：活子 ' + s.whiteStones + ' + 空 ' + s.whiteTerr.toFixed(1) + '<br>' +
      '公气 ' + s.dame + ' 点，各计 ' + (s.dame * 0.5).toFixed(1) + ' 子 · 死子 ' + s.deadCount + ' 颗');

    learnThisGame(s.winner);
  }

  /* ---------------- 申请数子 ---------------- */

  function countRow(label, detail, value) {
    return '<div class="cr"><span>' + label + ' <em>' + detail + '</em></span><b>' + value + '</b></div>';
  }

  function openCountRequest() {
    if (state.liveGame) backToLive();
    var g = state.game;
    if (g.gameOver) { setHint('对局已结束，直接确认结算即可。'); return; }
    if (state.thinking) { setHint('AI 思考中，等它落子后再申请。'); return; }
    if (g.current !== state.playerColor) { setHint('还没轮到你，稍等。'); return; }

    var ev = evaluateNow();
    if (!ev) { setHint('形势判断出了点问题，请重试。'); return; }

    els.cBlack.textContent = ev.black.toFixed(1);
    els.cWhite.textContent = ev.white.toFixed(1);

    var halfDame = (ev.dame * 0.5).toFixed(1);
    // 数子弹窗用"真数出来"的子差，与上面的胜负结论口径一致
    var rawLead = ev.winner === BLACK ? ev.diff : (ev.winner === WHITE ? -ev.diff : 0);
    els.countRows.innerHTML =
      countRow('黑方', '活子 ' + ev.blackStones + ' · 围空 ' + ev.blackTerr + ' · 未定 ' + halfDame,
        ev.black.toFixed(1) + ' 子') +
      countRow('白方', '活子 ' + ev.whiteStones + ' · 围空 ' + ev.whiteTerr + ' · 未定 ' + halfDame,
        ev.white.toFixed(1) + ' 子') +
      countRow('贴子', '黑贴 3.75 子', '黑胜线 ' + ev.line.toFixed(2)) +
      countRow('形势', '黑胜率 ' + (ev.blackWinrate * 100).toFixed(1) + '% · 未定 ' + ev.dame + ' 点',
        Analysis.leadText({ lead: rawLead }));

    var verdict;
    if (ev.winner === BLACK) verdict = '按此局面数子：黑胜 ' + ev.diff.toFixed(2) + ' 子';
    else if (ev.winner === WHITE) verdict = '按此局面数子：白胜 ' + ev.diff.toFixed(2) + ' 子';
    else verdict = '按此局面数子：和棋';
    els.countVerdict.textContent = verdict;

    var early = (ev.blackStones + ev.whiteStones) < g.N * 0.25;
    els.countNote.textContent = early
      ? '局面还早，围空估算误差较大，仅供参考；确认后会进入结算阶段，按死子标记正式数子。'
      : '以上为影响场估算，未计死子。确认后会按"无眼且仅剩两气"自动标死，' +
        '再逐个点选修正，最后正式结算。';

    els.countMask.hidden = false;
  }

  function closeCountRequest() { els.countMask.hidden = true; }

  function acceptAiCount() {
    els.countBar.hidden = true;
    enterScoring();
  }

  function declineAiCount() {
    els.countBar.hidden = true;
    setHint('已拒绝数子，继续对局。');
  }

  function learnThisGame(winner) {
    if (state.recorded || !state.moves.length) return;
    state.recorded = true;
    state.mem.recordGame(state.moves, winner, { human: true });
    state.mem.flush().then(function () {
      updateStatus();
      setHint('这局棋已写入本地记忆，AI 会从你的走法里继续学习。');
    });
  }

  /* ---------------- 操作 ---------------- */

  function newGame() {
    var size = parseInt(els.selSize.value, 10);
    state.playerColor = parseInt(els.selColor.value, 10);
    state.game = new Engine.GoGame(size, { komi: 3.75 });
    state.moves = [];
    state.suggestion = -1;
    state.hover = -1;
    state.recorded = false;
    state.thinking = false;
    state.aiRequested = false;
    state.liveGame = null;
    state.viewPly = 0;
    els.thinking.hidden = true;
    els.mask.hidden = true;
    els.scoringBar.hidden = true;
    els.countMask.hidden = true;
    els.countBar.hidden = true;
    resetTrend();
    applyStyle(true);
    render();
    var styleBit = state.styleName && state.styleName !== 'AI 本体'
      ? ' AI 以' + state.styleName + '镜像应战。' : '';
    setHint(size + ' 路对局开始。' + (state.playerColor === BLACK ? '你执黑先行。' : '你执白，AI 先行。') + styleBit);
    if (state.playerColor === WHITE) aiTurn();
  }

  function undo() {
    if (state.liveGame) backToLive();
    if (state.thinking) { setHint('AI 思考中，稍等一下再悔棋。'); return; }
    var g = state.game;
    var steps = 0;
    while (steps < 3 && g._stack.length > 0) {
      var wasPlayerTurn = g.current === state.playerColor;
      g.undo(); steps++;
      if (g.current === state.playerColor && !wasPlayerTurn) break;
      if (g.current === state.playerColor && steps >= 2) break;
    }
    if (!steps) { setHint('没有可悔的棋了。'); return; }
    state.moves.splice(Math.max(0, state.moves.length - steps), steps);
    state.recorded = false;
    els.mask.hidden = true;
    els.scoringBar.hidden = true;
    els.countMask.hidden = true;
    els.countBar.hidden = true;
    state.suggestion = -1;
    state.viewPly = state.moves.length;
    syncTrend();
    render();
    setHint('已悔棋 ' + steps + ' 步。');
  }

  function passTurn() {
    if (state.liveGame) backToLive();
    var g = state.game;
    if (g.gameOver || state.thinking) return;
    if (g.current !== state.playerColor) return;
    recordMove(-1, g.current);
    g.pass();
    state.viewPly = state.moves.length;
    pushTrend('pass');
    render();
    if (g.gameOver) { enterScoring(); return; }
    aiTurn();
  }

  function hint() {
    if (state.liveGame) backToLive();
    if (state.thinking || state.game.gameOver) return;
    if (state.game.current !== state.playerColor) return;
    setHint('AI 正在为你计算建议…');
    var t0 = performance.now();
    setTimeout(function () {
      var res = state.ai.chooseMove(state.game, { timeMs: 700 });
      if (res.move === -1) { setHint('AI 建议：此处可以弃一手。'); return; }
      state.suggestion = res.move;
      draw();
      setHint('建议落在 ' + coordName(res.move) + '（' + res.elapsed + 'ms / ' + res.iterations + ' 个分支）');
    }, 30);
  }

  // 双方停手，直接进入结算
  function countRequest() { openCountRequest(); }

  function resign() {
    if (state.liveGame) backToLive();
    if (state.game.gameOver) return;
    var g = state.game;
    g.gameOver = true;
    g.scoringPhase = false;
    var s = g.score();
    els.countBar.hidden = true;
    els.countMask.hidden = true;
    showResult('你认输了', 'AI 胜',
      '黑 ' + s.black.toFixed(1) + ' 子 / 白 ' + s.white.toFixed(1) + ' 子<br>认输方：' +
      (state.playerColor === BLACK ? '黑棋' : '白棋'));
    learnThisGame(state.playerColor === BLACK ? WHITE : BLACK);
  }

  /* ---------------- 事件 ---------------- */

  function pointFromEvent(e) {
    var rect = els.canvas.getBoundingClientRect();
    var px = (e.clientX - rect.left) * (geom.dim / rect.width);
    var py = (e.clientY - rect.top) * (geom.dim / rect.height);
    var gx = Math.round((px - geom.pad) / geom.cell);
    var gy = Math.round((py - geom.pad) / geom.cell);
    var size = state.game.size;
    if (gx < 0 || gy < 0 || gx >= size || gy >= size) return -1;
    var cx = geom.pad + gx * geom.cell, cy = geom.pad + gy * geom.cell;
    if (Math.hypot(cx - px, cy - py) > geom.cell * 0.58) return -1;
    return gy * size + gx;
  }

  els.canvas.addEventListener('click', function (e) {
    var i = pointFromEvent(e);
    if (i < 0) return;
    if (state.game.scoringPhase && state.game.gameOver) {
      state.game.toggleDead(i);
      render();
      showScorePreview();
      return;
    }
    playHuman(i);
  });

  els.canvas.addEventListener('mousemove', function (e) {
    var i = pointFromEvent(e);
    if (i !== state.hover) { state.hover = i; draw(); }
  });

  els.canvas.addEventListener('mouseleave', function () {
    if (state.hover !== -1) { state.hover = -1; draw(); }
  });

  els.btnNew.addEventListener('click', newGame);
  els.btnUndo.addEventListener('click', undo);
  els.btnPass.addEventListener('click', passTurn);
  els.btnHint.addEventListener('click', hint);
  els.btnResign.addEventListener('click', resign);
  els.btnCount.addEventListener('click', countRequest);
  els.btnAgain.addEventListener('click', newGame);

  // 申请数子弹窗
  els.btnCountCancel.addEventListener('click', closeCountRequest);
  els.btnCountOk.addEventListener('click', function () {
    closeCountRequest();
    var g = state.game;
    if (g.gameOver) return;
    g.consecutivePass = 2;
    g.gameOver = true;
    g.scoringPhase = true;
    enterScoring();
  });
  els.btnCountAccept.addEventListener('click', acceptAiCount);
  els.btnCountDecline.addEventListener('click', declineAiCount);

  // 形势判断
  els.chkTerritory.addEventListener('change', function () {
    state.showTerritory = els.chkTerritory.checked;
    draw();
  });

  els.btnRefreshEval.addEventListener('click', function () {
    render();
    var ev = state.eval;
    if (ev) {
      setHint('形势判断：' + Analysis.leadText(ev) + '，黑胜率 ' + (ev.blackWinrate * 100).toFixed(1) +
        '%，未定 ' + ev.dame + ' 点' + (ev.weak.length ? '，弱棋 ' + ev.weak.length + ' 块' : '') + '。');
    }
  });

  els.trend.addEventListener('mousemove', function (e) {
    var idx = trendHoverAt(e.clientX);
    if (idx !== state.trendHover) { state.trendHover = idx; drawTrend(); }
  });

  els.trend.addEventListener('mouseleave', function () {
    if (state.trendHover !== -1) { state.trendHover = -1; drawTrend(); }
  });

  els.trend.addEventListener('click', function (e) {
    if (!trendGeom) return;
    var idx = trendHoverAt(e.clientX);
    if (idx < 0) return;
    gotoPly(trendGeom.pts[idx].d.no);
  });

  var sliderRaf = 0;
  els.trendSlider.addEventListener('input', function () {
    if (sliderRaf) return;
    sliderRaf = requestAnimationFrame(function () {
      sliderRaf = 0;
      gotoPly(parseInt(els.trendSlider.value, 10));
    });
  });

  els.trendPrev.addEventListener('click', function () { gotoPly(state.viewPly - 1); });
  els.trendNext.addEventListener('click', function () { gotoPly(state.viewPly + 1); });
  els.trendLive.addEventListener('click', backToLive);

  els.btnAutoDead.addEventListener('click', function () {
    state.game.autoMarkDead(); render(); showScorePreview();
  });
  els.btnClearDead.addEventListener('click', function () {
    state.game.clearDead(); render(); showScorePreview();
  });
  els.btnConfirmScore.addEventListener('click', confirmScoring);

  els.selSize.addEventListener('change', newGame);
  els.selColor.addEventListener('change', newGame);

  els.selStyle.addEventListener('change', function () {
    if (state.thinking) {
      setHint('AI 正在思考，这盘下完再换棋风。');
      els.selStyle.value = state.styleMode;
      return;
    }
    applyStyle(false);
  });

  els.btnStudyAgain.addEventListener('click', function () {
    if (!state.worker) {
      setHint('训练进程还没起来，稍等几秒再点「再研习一遍」。');
      return;
    }
    if (state.studyRound >= 60) {
      setHint('棋谱已研习 60 遍，再练也不会更准了，接着下棋累积更实在。');
      return;
    }
    state.worker.postMessage({ type: 'study', passes: 1 });
    setHint('正在把全部棋谱再研习一遍……');
  });

  els.chkTrain.addEventListener('change', syncTrainerState);

  els.selTrainSize.addEventListener('change', function () {
    if (!state.worker) return;
    var size = parseInt(els.selTrainSize.value, 10);
    state.worker.postMessage({ type: 'config', size: size, movetime: trainMoveTime(size) });
    setHint('训练棋盘已切到 ' + size + ' 路' + (size >= 19 ? '（最终训练法，速度会明显变慢）' : '') +
      '，从下一局开始生效。');
  });

  els.btnClearMem.addEventListener('click', function () {
    if (!window.confirm('清空 AI 的全部记忆、段位进度与阶段存档？此操作不可恢复。')) return;
    state.mem.clear().then(function () {
      if (state.worker) state.worker.postMessage({ type: 'reset' });
      state.stageIndex = 0;
      state.stages = [];
      els.archList.innerHTML = '<span class="arch-empty">升段时自动保存上一阶段</span>';
      els.archCount.textContent = '';
      updateStatus();
      setHint('记忆已清空，AI 回到 18 级重新开始。');
    });
  });

  window.addEventListener('resize', function () {
    layout(); draw(); drawTrend();
  });

  /* ---------------- 训练 worker ---------------- */

  function trainMoveTime(size) {
    return size >= 19 ? 100 : (size >= 13 ? 55 : 40);
  }

  function trainerActive() {
    return !!state.worker && els.chkTrain.checked && !document.hidden;
  }

  // 训练只在软件窗口可见时进行：最小化 / 关闭窗口立即暂停
  function syncTrainerState() {
    if (!state.worker) return;
    var on = trainerActive();
    state.worker.postMessage({ type: on ? 'resume' : 'pause' });
    els.badgeTrain.textContent = on ? '训练中'
      : (els.chkTrain.checked ? '已暂停（窗口在后台）' : '已暂停');
    els.badgeTrain.classList.toggle('live', on);
    els.trainLive.hidden = !on;
  }

  function startTrainer() {
    if (state.worker) return;
    try {
      state.worker = new Worker('js/trainer.worker.js');
    } catch (err) {
      els.badgeTrain.textContent = '训练不可用';
      setHint('后台训练进程启动失败，棋力仍可正常对局。');
      return;
    }
    state.worker.onerror = function (e) {
      els.badgeTrain.textContent = '训练异常';
      els.badgeTrain.classList.remove('live');
      setHint('训练进程出错：' + (e.message || '未知错误') + '（棋力仍可正常对局）');
    };
    state.worker.onmessage = function (e) {
      var d = e.data || {};
      if (d.type === 'ready') {
        state.workerReady = true;
        syncTrainerState();
      } else if (d.type === 'progress') {
        state.mem.reload().then(function () {
          updateStatus();
          if (d.speed !== undefined) {
            els.trainSpeed.textContent = d.speed > 0 ? d.speed.toFixed(1) + ' 局/分' : '—';
          }
        });
      } else if (d.type === 'study') {
        state.studyRound = d.round;
        if (state.mem && d.stats) {
          state.mem.meta.studyPasses = d.stats.studyPasses;
          state.mem.meta.studyMoves = d.stats.studyMoves;
          updateStatus();
        }
        els.badgeTrain.textContent = '研习棋谱第 ' + d.round + ' 遍';
        els.badgeTrain.classList.add('live');
        // 研习期间也要落盘，防止关窗口丢进度
      } else if (d.type === 'studyDone') {
        state.studyRound = d.round;
        state.mem.reload().then(function () {
          updateStatus();
          setHint('全部棋谱已研习 ' + d.round + ' 遍，共 ' + Math.round((d.stats && d.stats.studyMoves) || 0) +
            ' 手。AI 的棋型判断与开局库都更新了。');
        });
      } else if (d.type === 'error') {
        els.badgeTrain.textContent = '训练异常';
      }
    };

    var size = parseInt(els.selTrainSize.value, 10);
    state.worker.postMessage({ type: 'config', size: size, movetime: trainMoveTime(size) });
    syncTrainerState();
  }

  // 窗口隐藏（最小化 / 切走）就暂停训练，回来继续
  document.addEventListener('visibilitychange', function () {
    syncTrainerState();
  });

  // 关闭软件：先停训练、落盘，再销毁 worker
  function stopTrainer() {
    if (!state.worker) return;
    try {
      state.worker.postMessage({ type: 'pause' });
      if (state.mem) state.mem.flush();
      state.worker.terminate();
    } catch (e) { /* ignore */ }
    state.worker = null;
  }

  window.addEventListener('beforeunload', stopTrainer);
  window.addEventListener('pagehide', stopTrainer);

  /* ---------------- 启动 ---------------- */

  async function boot() {
    try {
      state.mem = new window.GoMemoryLib.GoMemory();
      await state.mem.init();
      state.ai = new GoAI(state.mem, { timeMs: 900, cPuct: 1.6 });
      buildStyles();
      applyStyle(true);

      var st0 = state.mem.stats();
      state.stageIndex = stageInfo((st0.games || 0) + (st0.humanGames || 0)).index;
      loadStages();

      state.viewPly = 0;
      resetTrend();
      render();
      updateEvalUI();
      setHint('19 路对局开始，你执黑先行。AI 在窗口打开时自动训练，关闭窗口即停止。');
      startTrainer();

      // 定期把 worker 写入的记忆同步过来
      setInterval(function () {
        state.mem.reload().then(updateStatus).catch(function () { });
      }, 15000);
    } catch (err) {
      setHint('启动失败：' + (err && err.message ? err.message : err));
      if (window.console) console.error(err);
    }
  }

  window.addEventListener('error', function (e) {
    if (e && e.message) setHint('运行异常：' + e.message);
  });

  boot();
})();
